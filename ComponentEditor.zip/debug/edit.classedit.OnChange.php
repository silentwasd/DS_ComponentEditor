<?php Editor::changeClass($self->text);
Editor::$temp->class = $self->text;
Editor::genInfo();
