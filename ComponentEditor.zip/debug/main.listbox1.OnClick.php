<?php $index = $self->itemIndex;
if ($index != -1) {
    $component = Components::$items[$index];
    c("classLabel")->caption = $component->class;
    c("groupLabel")->caption = $component->group;
    c("captionLabel")->caption = $component->caption;
    c("nameLabel")->caption = $component->name;
    c("sortLabel")->caption = $component->sort;
    c("extendsLabel")->caption = $component->extends ? $component->extends : "";
}
