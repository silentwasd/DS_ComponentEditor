<?php Editor::formInit();
