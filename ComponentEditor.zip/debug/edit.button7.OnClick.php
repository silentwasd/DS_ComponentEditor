<?php Editor::$sourceSel = "properties";
c("synEditEx1")->text = Editor::$temp->source['properties'];
