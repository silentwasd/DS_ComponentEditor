<?php Editor::$sourceSel = "events";
c("synEditEx1")->text = Editor::$temp->source['events'];
