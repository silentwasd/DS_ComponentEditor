<?php class Editor {
    static public $object;
    static public $temp;
    static public $sourceSel = 'module';
    
    static function genEvents() {
		$events = self::$temp->events;
		$arr = "";
		if ($events) {
			foreach ($events as $event) {
				$caption = $event->caption;
				$function = $event->function;
				$pattern = $event->pattern;
				$icon = $event->icon;
				
				$arr .= "\$result[] = array(\r\n\t'CAPTION' => '$caption',\r\n\t'EVENT' => '$function',\r\n\t'INFO' => '$pattern',\r\n\t'ICON' => '$icon'\r\n);\r\n\r\n";
			}
		}
		
		$code = "<?\r\n\$result = array();\r\n\r\n{SPACE_FOR_CODE}return \$result;";
		self::$temp->source['events'] = str_replace("{SPACE_FOR_CODE}", $arr, $code);
    }
    
    static function genMethods() {
		$methods = self::$temp->methods;
		$arr = "";
		if ($methods) {
			foreach ($methods as $method) {
				$caption = $method->caption;
				$function = $method->function;
				$hint = $method->hint;

				$arr .= "\$result[] = array(\r\n\t'CAPTION' => '$caption',\r\n\t'PROP' => '$function',\r\n\t'INLINE' => '$hint',\r\n);\r\n\r\n";
			}
		}
		
		$code = "<?\r\n\$result = array();\r\n\r\n{SPACE_FOR_CODE}return \$result;";
		self::$temp->source['methods'] = str_replace("{SPACE_FOR_CODE}", $arr, $code);
    }
    
    static function genProperties() {
		$properties = self::$temp->properties;
		$arr = "";
		if ($properties) {
			foreach ($properties as $property) {
				$caption = $property->caption;
				$type = $property->type;
				$variable = $property->variable;
				$realVar = $property->realVar;
				$class = $property->class;
				$values = $property->values;
				$toExtends = $property->toExtends;
				$updateDesign = $property->updateDesign;
				
				if (is_array($values)) {
					$_values = array();
					foreach ($values as $value) {
						$_values[] = "'$value'";
					}
					$values = implode(",", $_values);
				}

				$arr .= "\$result[] = array(\r\n\t'CAPTION' => '$caption',\r\n\t'TYPE' => '$type',\r\n\t'PROP' => '$variable',\r\n\t'REAL_PROP' => '$realVar',\r\n\t'CLASS' => '$class',\r\n\t'VALUES' => array($values),\r\n\t'ADD_GROUP' => '$toExtends',\r\n\t'UPDATE_DSGN' => '$updateDesign',\r\n);\r\n\r\n";
			}
		}

		$code = "<?\r\n\$result = array();\r\n\r\n{SPACE_FOR_CODE}return \$result;";
		self::$temp->source['properties'] = str_replace("{SPACE_FOR_CODE}", $arr, $code);
    }
    
    static function genInfo() {
		$class = self::$temp->class;
		$group = self::$temp->group;
		$caption = self::$temp->caption;
		$name = self::$temp->name;
		$sort = self::$temp->sort;
		$useSkin = self::$temp->useSkin;
		$w = self::$temp->w;
		$h = self::$temp->h;
		
		$modules = self::$temp->modules;
		$list = array();
		if ($modules) {
			foreach ($modules as $module) {
				$list[] = "'$module'";
			}
			$modules = implode(",", $list);
		}
		else $modules = "";
		
		$dlls = self::$temp->dlls;
		$list = array();
		if ($dlls) {
			foreach ($dlls as $dll) {
				$list[] = "'$dll'";
			}
			$dlls = implode(",", $list);
		}
		else $dlls = "";
		
		$arr = "\$result['CLASS'] = '$class';\r\n";
		$arr .= "\$result['GROUP'] = '$group';\r\n";
		$arr .= "\$result['CAPTION'] = '$caption';\r\n";
		$arr .= "\$result['NAME'] = '$name';\r\n";
		$arr .= "\$result['SORT'] = '$sort';\r\n";
		$arr .= "\$result['USE_SKIN'] = '$useSkin';\r\n";
		$arr .= "\$result['W'] = '$w';\r\n";
		$arr .= "\$result['H'] = '$h';\r\n";
		$arr .= "\$result['MODULES'] = array($modules);\r\n";
		$arr .= "\$result['DLLS'] = array($dlls);\r\n";
		
		$code = "<?\r\n\$result = array();\r\n\r\n{SPACE_FOR_CODE}return \$result;";
		self::$temp->source['info'] = str_replace("{SPACE_FOR_CODE}", $arr, $code);
    }
    
    static function componentInit() {
		$initModule = RSC_PATH . "initModule.txt";
		$pattern = file_exists($initModule) ? file_get_contents($initModule) : null;
		if (!isset($pattern)) messageBox("�� ������ ������ �� ����:\r\n$initModule", "������", MB_ICONERROR);
		else {
			$pattern = str_replace("%class%", self::$temp->class, $pattern);
			$pattern = str_replace("%extends%", self::$temp->extends, $pattern);
			self::$temp->source['module'] = $pattern;
			c("Edit->synEditEx1")->text = self::$temp->source['module'];
		}
    }
    
    static function changeClass($class) {
		$source = self::$temp->source['module'];
		self::$temp->source['module'] = preg_replace('/class .* extends/i', "class $class extends", $source);
		if (self::$sourceSel == "module") c("Edit->synEditEx1")->text = self::$temp->source['module'];
    }
    
    static function changeExtends($extends) {
		$source = self::$temp->source['module'];
		self::$temp->source['module'] = preg_replace('/extends\s.*\s\{/i', "extends $extends {", $source);
		if (self::$sourceSel == "module") c("Edit->synEditEx1")->text = self::$temp->source['module'];
    }
    
    static function formInit() {
		$temp = self::$temp = clone self::$object;
		Editor::$sourceSel = "module";
		
		c("classEdit")->text = $temp->class;
		c("groupEdit")->inText = $temp->group;
		c("groupEdit")->text = Components::getGroups();
		c("captionEdit")->text = $temp->caption;
		c("nameEdit")->text = $temp->name;
		c("sortEdit")->text = $temp->sort;
		c("synEditEx1")->text = $temp->source['module'];
		c("extendsEdit")->inText = $temp->extends ? $temp->extends : "";
		c("skinCheck")->checked = $temp->useSkin;

		$module = Components::getModuleExtends();
		$classes = Components::getClasses();
		$extends = array_merge($module, $classes);
		c("extendsEdit")->text = array_unique($extends);

		self::genEvents();
		self::genMethods();
		self::genProperties();
		self::genInfo();
    }
}

TSynHighlighter($self, array('HTML', 'SynHTML'));
TSynHighlighter($self, array('PHP', 'SynPHP'));
TSynHighlighter($self, array('General', 'SynGeneral'));
TSynHighlighter($self, array('Cpp', 'SynCpp'));
TSynHighlighter($self, array('Css', 'SynCss'));
TSynHighlighter($self, array('SQL', 'SynSQL'));
TSynHighlighter($self, array('JScript', 'SynJScript'));
TSynHighlighter($self, array('XML', 'SynXML'));

################################################## ��� SynEdit
/*$s = new TSynEdit;
$s->name = 'TSynEdit1';
$s->parent = $self;
$s->w = $self->clientWidth;
$s->h = $self->clientHeight;
$s->WantTabs = true;
gui_propSet($s->gutter, 'ShowLineNumbers', true);*/

SPHP();
