<?php $index = c("listBox1")->itemIndex;
if ($index != -1) {
	unset(Editor::$temp->methods[$index]);
	Editor::$temp->methods = array_values(Editor::$temp->methods);
	MethodsForm::init();
}
