<?php c("Methods")->showModal();
