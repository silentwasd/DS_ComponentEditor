<?php Editor::$sourceSel = "info";
c("synEditEx1")->text = Editor::$temp->source['info'];
