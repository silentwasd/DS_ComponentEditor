<?php $sourceSel = Editor::$sourceSel;
if ($sourceSel == "module") Editor::$temp->source['module'] = $self->text;
