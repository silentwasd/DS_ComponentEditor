<?php $index = $self->itemIndex;
Editor::$temp->methods[] = Resources::$methods[$index];
MethodsForm::init();
