<?php $config = file_exists("config.ini") ? Resources::parseINI("config.ini") : array();

define("CMP_PATH", $config['components']);
define("IMG_PATH", $config['images24']);
define("RSC_PATH", $config['resources']);
define("EXT_PATH", $config['extensions']);

Components::scan();

class Component {
    public $group;
    public $class;
    public $caption;
    public $sort;
    public $name;
    public $w;
    public $h;
    public $modules;
    public $events;
    public $methods;
    public $properties;
    public $source;
	public $extends;
	public $useSkin;
	public $dlls;
    
    function __construct($group, $class, $caption, $sort, $name, $useSkin = false, $modules = null, $dlls = null, $w = null, $h = null) {
        $this->group = $group;
        $this->class = $class;
        $this->caption = $caption;
        $this->sort = $sort;
        $this->name = $name;
        $this->useSkin = $useSkin;
        $this->modules = $modules;
        $this->dlls = $dlls;
        $this->w = $w;
        $this->h = $h;
        
        $this->events = array();
        $this->methods = array();
        $this->properties = array();
    }
}

class Event {
    public $caption;
    public $function;
    public $pattern;
    public $icon;
    
    function __construct($caption, $function, $pattern, $icon = null) {
        $this->caption = $caption;
        $this->function = $function;
        $this->pattern = $pattern;
        $this->icon = $icon;
    }
}

class Method {
    public $caption;
    public $function;
    public $hint;
    
    function __construct($caption, $function, $hint = null) {
        $this->caption = $caption;
        $this->function = $function;
        $this->hint = $hint;
    }
}

class Property {
    public $caption;
    public $type;
    public $variable;
    public $realVar;
    public $class;
    public $values;
    public $toExtends;
    public $updateDesign;
    
    function __construct($caption, $type, $variable, $realVar = null, $class = null, $values = null, $toExtends = null, $updateDesign = null) {
        $this->caption = $caption;
        $this->type = $type;
        $this->variable = $variable;
        $this->realVar = $realVar;
        $this->class = $class;
        $this->values = $values;
        $this->toExtends = $toExtends;
        $this->updateDesign = $updateDesign;
    }
}

class Components {
	static public $items;
	static public $deleted;

	static function scan() {
		dir_search(CMP_PATH, $info, "php", false, true);
		$items = array();
		foreach ($info as $__item) {
			include($__item);
			$item = new Component(
				$result['GROUP'],
				$result['CLASS'],
				$result['CAPTION'],
				$result['SORT'],
				$result['NAME'],
				$result['USE_SKIN'],
				$result['MODULES'],
				$result['DLLS'],
				$result['W'],
				$result['H']
			);
			$item->source['info'] = file_get_contents($__item);

			$name = basename($__item);

			$events = CMP_PATH . "events/$name";
			if (file_exists($events)) {
				$item->source['events'] = file_get_contents($events);
				include($events);
				foreach ($result as $_item) {
					$item->events[] = new Event(
						$_item['CAPTION'],
						$_item['EVENT'],
						$_item['INFO'],
						$_item['ICON']
					);
				}
			}

			$methods = CMP_PATH . "methods/$name";
			if (file_exists($methods)) {
				$item->source['methods'] = file_get_contents($methods);
				include($methods);
				foreach ($result as $_item) {
					$item->methods[] = new Method(
						$_item['CAPTION'],
						$_item['PROP'],
						$_item['INLINE']
					);
				}
			}

			$properties = CMP_PATH . "properties/$name";
			if (file_exists($properties)) {
				$item->source['properties'] = file_get_contents($properties);
				include($properties);
				foreach ($result as $_item) {
					$item->properties[] = new Property(
						$_item['CAPTION'],
						$_item['TYPE'],
						$_item['PROP'],
						$_item['REAL_PROP'],
						$_item['CLASS'],
						$_item['VALUES'],
						$_item['ADD_GROUP'],
						$_item['UPDATE_DSGN']
					);
				}
			}

			$module = CMP_PATH . "modules/$name";
			if (file_exists($module)) {
				$content = file_get_contents($module);
				if (preg_match('/class .* extends (.*) \{/', $content, $matches)) {
					$item->extends = $matches[1];
				}
				$item->source['module'] = $content;
			}
			
			$items[] = $item;
		}
		self::$items = $items;
	}
	
	static function getGroups() {
        $items = self::$items;
        $list = array();
        foreach ($items as $item) {
            $list[] = $item->group;
        }
        return array_unique($list);
	}
	
	static function getPropTypes() {
		$items = self::$items;
        $list = array();
        foreach ($items as $item) {
            $props = $item->properties;
            foreach ($props as $prop) {
				$list[] = $prop->type;
            }
        }
        return array_unique($list);
	}
	
	static function getModuleExtends() {
		$items = self::$items;
        $list = array();
        foreach ($items as $item) {
			$list[] = $item->extends;
        }
        return $list;
	}
	
	static function getClasses() {
		$items = self::$items;
        $list = array();
        foreach ($items as $item) {
			$list[] = $item->class;
        }
        return $list;
	}
}

class Images {
	static function getIcons() {
		dir_search(IMG_PATH, $images, "bmp", false, false);
		foreach ($images as $image) {
			$list[] = basenameNoExt($image);
		}
		return $list;
	}
}

class Resources {
	static public $events;
	static public $methods;
	static public $properties;

	static function loadEvents() {
		dir_search("resources/events", $_items, false, true);
		$items = array();
		foreach ($_items as $_item) {
			$item = self::parseINI($_item);
			$items[] = new Event($item['caption'], $item['function'], $item['pattern'], $item['icon']);
		}
		self::$events = $items;
	}
	
	static function loadMethods() {
		dir_search("resources/methods", $_items, false, true);
		$items = array();
		foreach ($_items as $_item) {
			$item = self::parseINI($_item);
			$items[] = new Method($item['caption'], $item['function'], $item['hint']);
		}
		self::$methods = $items;
	}
	
	static function loadProperties() {
		dir_search("resources/properties", $_items, false, true);
		$items = array();
		foreach ($_items as $_item) {
			$item = self::parseINI($_item);

			if ($item['values']) {
				$values = explode(",", $item['values']);
			}
			else $values = null;
			
			$items[] = new Property($item['caption'], $item['type'], $item['variable'], $item['realVar'], $item['class'], $values, $item['toExtends'], $item['updateDesign']);
		}
		self::$properties = $items;
	}
	
	static function getEvents() {
		$items = self::$events;
		foreach ($items as $item) {
			$list[] = $item->caption;
		}
		return $list;
	}
	
	static function getMethods() {
		$items = self::$methods;
		foreach ($items as $item) {
			$list[] = $item->caption;
		}
		return $list;
	}
	
	static function getProperties() {
		$items = self::$properties;
		foreach ($items as $item) {
			$list[] = $item->caption;
		}
		return $list;
	}
	
	static function parseINI($file) {
		if (file_exists($file)) {
			$content = file_get_contents($file);
			if ($content) {
				$strs = explode("\r\n", $content);
				$keys = array();
				foreach ($strs as $str) {
					if (preg_match('/^([a-zA-Z\s_0-9]+)=(.*)$/', $str, $matches)) {
						$keys[$matches[1]] = $matches[2];
					}
				}
				return $keys;
			}
			else return false;
		}
		else return false;
	}
}

Resources::loadEvents();
Resources::loadMethods();
Resources::loadProperties();
