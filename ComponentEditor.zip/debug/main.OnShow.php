<?php c("listBox1")->text = Components::getClasses();
