<?php Editor::$sourceSel = "methods";
c("synEditEx1")->text = Editor::$temp->source['methods'];
