<?php class MethodsForm {
	static function init() {
		$methods = Editor::$temp->methods;
		if ($methods) {
			$list = array();
			foreach ($methods as $method) {
				$list[] = $method->caption;
			}
			c("Methods->listBox1")->text = $list;
		}
		else c("Methods->listBox1")->text = "";
		c("methodsEdit")->text = Resources::getMethods();
	}
}
