<?php $index = $self->itemIndex;
if ($index != -1) {
    $component = Components::$items[$index];
    Editor::$object = $component;
    c("Edit")->showModal();
    
    Components::$items[$index] = Editor::$object;
	c("listBox1")->text = Components::getClasses();
}
