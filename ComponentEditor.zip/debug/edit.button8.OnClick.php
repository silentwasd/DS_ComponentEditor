<?php Editor::formInit();
c("Edit")->close();
