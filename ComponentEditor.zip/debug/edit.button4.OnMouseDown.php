<?php if ($button == 1) Editor::componentInit();
