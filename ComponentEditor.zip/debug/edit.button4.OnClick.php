<?php Editor::$sourceSel = "module";
c("synEditEx1")->text = Editor::$temp->source['module'];
