<?php class EventsForm {
	static function init() {
		$events = Editor::$temp->events;
		if ($events) {
			$list = array();
			foreach ($events as $event) {
				$list[] = $event->caption;
			}
			c("Events->listBox1")->text = $list;
		}
		else c("Events->listBox1")->text = "";
		c("Events->iconEdit")->text = Images::getIcons();
		c("Events->eventsEdit")->text = Resources::getEvents();
	}
}
