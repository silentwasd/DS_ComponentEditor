<?php class AddonsForm {
	static function init() {
		$exts = Editor::$temp->modules;
		$_dlls = Editor::$temp->dlls;
		
		$dlls = array();
		if ($_dlls) {
			foreach ($_dlls as $dll) {
				if (preg_match('/^.+\..+$/', $dll)) {
					$dlls[] = $dll;
				}
				else $dlls[] = "[$dll]";
			}
		}
		
		c("Addons->listBox1")->text = $exts;
		c("Addons->listBox2")->text = $dlls;
		
		dir_search(EXT_PATH, $extsFiles, "dll", false, false);
		c("extEdit")->text = $extsFiles;
	}
}
