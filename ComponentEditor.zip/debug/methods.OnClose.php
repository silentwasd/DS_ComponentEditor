<?php Editor::genMethods();
