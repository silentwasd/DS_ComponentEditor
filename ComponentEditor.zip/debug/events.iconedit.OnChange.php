<?php c("image1")->loadFromFile(IMG_PATH . $self->inText . ".bmp");
