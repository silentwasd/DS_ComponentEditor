<?php $index = $self->itemIndex;
if ($index != -1) {
	$event = Editor::$temp->events[$index];
	c("captionEdit")->text = $event->caption;
	c("functionEdit")->text = $event->function;
	c("patternEdit")->text = $event->pattern;
	c("iconEdit")->inText = $event->icon;
	c("image1")->loadFromFile(IMG_PATH . $event->icon . ".bmp");
}
