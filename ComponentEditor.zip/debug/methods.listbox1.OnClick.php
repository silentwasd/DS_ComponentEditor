<?php $index = $self->itemIndex;
if ($index != -1) {
	$method = Editor::$temp->methods[$index];
	c("captionEdit")->text = $method->caption;
	c("functionEdit")->text = $method->function;
	c("hintEdit")->text = $method->hint;
}
