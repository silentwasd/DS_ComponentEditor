<?php Editor::$temp->name = $self->text;
Editor::genInfo();
