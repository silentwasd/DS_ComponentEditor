<?php Editor::$temp->sort = $self->text;
Editor::genInfo();
