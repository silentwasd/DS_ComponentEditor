<?php class PropertiesForm {
	static function init() {
		$properties = Editor::$temp->properties;
		if ($properties) {
			$list = array();
			foreach ($properties as $property) {
				$list[] = $property->caption;
			}
			c("Properties->listBox1")->text = $list;
		}
		else c("Properties->listBox1")->text = "";
		c("typeEdit")->text = Components::getPropTypes();
		c("propertiesEdit")->text = Resources::getProperties();
	}
}
