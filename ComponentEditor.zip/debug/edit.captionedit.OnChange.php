<?php Editor::$temp->caption = $self->text;
Editor::genInfo();
