<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'TSkype';
$result['SORT']    = 613;
$result['NAME']    = 'TSkype';

return $result;

?>