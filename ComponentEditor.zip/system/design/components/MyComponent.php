<?
$result = array();

$result['CLASS'] = 'MyComponent';
$result['GROUP'] = 'additional';
$result['CAPTION'] = '����� ���������';
$result['NAME'] = 'newComponent';
$result['SORT'] = '1000';
$result['USE_SKIN'] = '';
$result['W'] = '';
$result['H'] = '';
$result['MODULES'] = array();
$result['DLLS'] = array();
return $result;