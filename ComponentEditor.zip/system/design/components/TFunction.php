<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TFunction_Caption');
$result['SORT']    = 610;
$result['NAME']    = 'myFunc';

return $result;