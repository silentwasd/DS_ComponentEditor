<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TStringGrid_Caption');
$result['SORT']    = 493;
$result['NAME']    = 'grid';
$result['W']       = 20;
$result['H']       = 20;

return $result;