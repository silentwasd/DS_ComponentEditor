<?

$result = array();

$result['GROUP']   = 'dialogs';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TSampleDialog_Caption');
$result['SORT']    = 1070;
$result['NAME']    = 'dialog';


return $result;