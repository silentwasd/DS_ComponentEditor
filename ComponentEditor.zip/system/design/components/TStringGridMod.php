<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('StringGridMod');
$result['SORT']    = 100;
$result['NAME']    = 'gridMod';
$result['W']       = 20;
$result['H']       = 20;

return $result;