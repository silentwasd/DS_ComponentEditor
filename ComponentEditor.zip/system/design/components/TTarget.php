<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'Target';
$result['SORT']    = 294;
$result['NAME']    = 'Target';


return $result;