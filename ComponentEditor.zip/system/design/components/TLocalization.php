<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TLocalization_Caption');
$result['SORT']    = 790;
$result['NAME']    = 'locale';

return $result;