<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TListbox_Caption');
$result['SORT']    = 290;
$result['NAME']    = 'listBox';
$result['W']       = 20;
$result['H']       = 20;

return $result;