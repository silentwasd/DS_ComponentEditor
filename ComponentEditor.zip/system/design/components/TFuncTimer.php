<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TFuncTimer_Caption');
$result['SORT']    = 600;
$result['NAME']    = 'timer';

return $result;