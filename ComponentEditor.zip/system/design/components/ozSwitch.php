<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Switch');
$result['SORT']    = 1;
$result['NAME']    = 'ozSwitch';

$result['W']       = 6;
$result['H']       = 3;

return $result;