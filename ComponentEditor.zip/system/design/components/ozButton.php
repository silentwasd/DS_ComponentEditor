<?
$result = array();

$result['CLASS'] = 'ozButton';
$result['GROUP'] = 'DevelStudio AE';
$result['CAPTION'] = 'Button';
$result['NAME'] = 'ozButton';
$result['SORT'] = '1';
$result['W'] = '16';
$result['H'] = '4';
$result['MODULES'] = array();
return $result;