<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('CattegoryButtons');
$result['SORT']    = 450;
$result['NAME']    = 'categoryButtons';

$result['buttonOptions'] = 'boShowCaptions,boFullSize,boGradientFill,boBoldCaptions,boUsePlusMinus,boCaptionOnlyBorder';

$result['W'] = 20;
$result['H'] = 55;

return $result;