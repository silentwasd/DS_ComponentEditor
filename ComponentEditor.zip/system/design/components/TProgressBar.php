<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TProgressBar_Caption');
$result['SORT']    = 293;
$result['NAME']    = 'progress';
$result['WINCONTROL'] = false;

$result['W'] = 30;
$result['H'] = 3;

return $result;