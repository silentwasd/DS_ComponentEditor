<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('SynEdit');
$result['SORT']    = 999;

$result['NAME']    = 'synEdit';

$result['W'] = 20;
$result['H'] = 15;
//$result['alignment'] = 'taLeftJustify';
$result['PROPS'] = array('rightEdge' => 80, 'alignment' => 'taLeftJustify', 'ActiveLineColor' => clWindow );

return $result;