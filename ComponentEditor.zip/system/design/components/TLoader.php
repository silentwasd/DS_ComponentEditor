<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TLoader');
$result['SORT']    = 235;

$result['NAME']    = 'loader';

$result['W'] = 20;
$result['H'] = 15;

return $result;