<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'SynEditEx';
$result['SORT']    = 613;
$result['NAME']    = 'synEditEx';

$result['W'] = 20;
$result['H'] = 15;

$result['PROPS'] = array('rightEdge' => 80, 'alignment' => 'taLeftJustify', 'ActiveLineColor' => clWindow );
return $result;

?>