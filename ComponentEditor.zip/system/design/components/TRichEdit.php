<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TRichEdit_Caption');
$result['SORT']    = 405;

$result['NAME']    = 'richEdit';

$result['W'] = 40;
$result['H'] = 25;

return $result;