<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TRadioGroup_Caption');
$result['SORT']    = 420;
$result['NAME']    = 'radioGroup';
$result['WINCONTROL'] = false;

$result['W'] = 30;
$result['H'] = 20;

return $result;