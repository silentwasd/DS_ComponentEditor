<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TLabel_Caption');
$result['SORT']    = 200;
$result['NAME']    = 'label';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 10;
$result['H'] = 2;

return $result;