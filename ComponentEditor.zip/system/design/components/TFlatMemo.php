<?

/* Компонент TFlatMemo - плоская версия TMemo
Автор компонента: Ваня Стасевич (Дима Скрипов) (vk.com/mrcloudcraft)
Версия компонента: 1.3

vk.com/copersoft
*/

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Flat Memo');
$result['SORT']    = 1;
$result['NAME']    = 'flatMemo';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 25;
$result['H'] = 15;

return $result;