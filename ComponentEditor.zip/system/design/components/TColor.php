<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'Color';
$result['SORT']    = 1700;
$result['NAME']    = 'Color';

$result['W'] = 25;
$result['H'] = 20;

return $result;