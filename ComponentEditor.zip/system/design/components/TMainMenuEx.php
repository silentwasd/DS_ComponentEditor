<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TMainMenu_Caption');
$result['SORT']    = 720;
$result['NAME']    = 'mainMenu';


$result['IS_ONE']  = true;


return $result;