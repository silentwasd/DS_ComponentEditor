<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TScrollBar_Caption');
$result['SORT']    = 460;
$result['NAME']    = 'scrollBar';
$result['WINCONTROL'] = false;

$result['W'] = 25;
$result['H'] = 2;

return $result;