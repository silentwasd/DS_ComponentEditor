<?

//**************************************************//
//********************ProgressBarEx2.2**************//
//********************By Roman**********************//
//**************************************************//

$result = array();

$result[] = array(
                  'CAPTION'=>t('Progress'),
                  'PROP'=>'Progress',
                  'INLINE'=>'Progress ( string max position, string position)',
                  );
$result[] = array(
                  'CAPTION'=>t('load_image'),
                  'PROP'=>'load_image',
                  'INLINE'=>'load_image ( string FileName)',
                  );
return $result;