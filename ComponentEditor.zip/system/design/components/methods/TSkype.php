<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('userstats'),
                  'PROP'=>'userstatus($login)',
                  'INLINE'=>'userstatus($login)',
                  );

$result[] = array(
                  'CAPTION'=>t('moodtext'),
                  'PROP'=>'moodtext($text)',
                  'INLINE'=>'moodtext($text)',
                  );
				  
$result[] = array(
                  'CAPTION'=>t('away'),
                  'PROP'=>'away()',
                  'INLINE'=>'away( void )',
                  );	

$result[] = array(
                  'CAPTION'=>t('offline'),
                  'PROP'=>'offline()',
                  'INLINE'=>'offline( void )',
                  );				  
				  
$result[] = array(
                  'CAPTION'=>t('online'),
                  'PROP'=>'online()',
                  'INLINE'=>'online( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('invisible'),
                  'PROP'=>'invisible()',
                  'INLINE'=>'invisible( void )',
                  );
$result[] = array(
                  'CAPTION'=>t('message'),
                  'PROP'=>'message($login, $text)',
                  'INLINE'=>'message($login, $text)',
                  );
$result[] = array(
                  'CAPTION'=>t('call'),
                  'PROP'=>'call($login)',
                  'INLINE'=>'call($login)',
                  );

return $result;

?>