<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('formList'),
                  'PROP'=>'formList()',
                  'INLINE'=>'formList ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('scrollBy'),
                  'PROP'=>'scrollBy',
                  'INLINE'=>'scrollBy ( int x, int y )',
                  );

return $result;