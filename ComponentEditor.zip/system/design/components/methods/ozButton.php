<?
$result = array();

$result[] = array(
	'CAPTION' => 'Set date',
	'PROP' => 'setDate()',
	'INLINE' => 'setDate ( void )',
);

$result[] = array(
	'CAPTION' => 'Show',
	'PROP' => 'show()',
	'INLINE' => 'show ( void )',
);

$result[] = array(
	'CAPTION' => 'Hide',
	'PROP' => 'hide()',
	'INLINE' => 'hide ( void )',
);

$result[] = array(
	'CAPTION' => 'To back',
	'PROP' => 'toBack()',
	'INLINE' => 'toBack ( void )',
);

$result[] = array(
	'CAPTION' => 'To front',
	'PROP' => 'toFront()',
	'INLINE' => 'toFront ( void )',
);

$result[] = array(
	'CAPTION' => 'Invalidate',
	'PROP' => 'invalidate()',
	'INLINE' => 'invalidate ( void )',
);

$result[] = array(
	'CAPTION' => 'Repaint',
	'PROP' => 'repaint()',
	'INLINE' => 'repaint ( void )',
);

$result[] = array(
	'CAPTION' => 'Perform',
	'PROP' => 'perform',
	'INLINE' => 'perform ( string msg, int hparam, int lparam )',
);

$result[] = array(
	'CAPTION' => 'Create',
	'PROP' => 'create',
	'INLINE' => 'create ( [object parent = activeForm] )',
);

$result[] = array(
	'CAPTION' => 'Free',
	'PROP' => 'free()',
	'INLINE' => 'free ( void )',
);

$result[] = array(
	'CAPTION' => 'Set focus',
	'PROP' => 'setFocus()',
	'INLINE' => 'setFocus ( void )',
);

$result[] = array(
	'CAPTION' => 'Set time',
	'PROP' => 'setTime()',
	'INLINE' => 'setTime ( void )',
);

return $result;