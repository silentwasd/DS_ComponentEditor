<?

$result = array();

$result[] = array(
                  'CAPTION'=>'Target',
                  'PROP'=>'Target()',
                  'INLINE'=>'Target ( $Object , [$Color] ) - Target The Object.',
                  );
				  
$result[] = array(
                  'CAPTION'=>'Move',
                  'PROP'=>'Move()',
                  'INLINE'=>'Move ( void ) - Move The Object.',
                  );
				  
$result[] = array(
                  'CAPTION'=>'ClearTargets',
                  'PROP'=>'ClearTargets()',
                  'INLINE'=>'ClearTargets ( void ) - Clear Targets.',
                  );
				  
$result[] = array(
                  'CAPTION'=>'Get_Obj',
                  'PROP'=>'Get_Obj()',
                  'INLINE'=>'Get_Obj ( void ) - Returns The Selected Object.',
                  );

$result[] = array(
                  'CAPTION'=>'Class_Name',
                  'PROP'=>'Class_Name()',
                  'INLINE'=>'Class_Name ( void ) - Returns The Class Name Of The Selected Object.',
                  );

$result[] = array(
                  'CAPTION'=>'Class_Name_Ex',
                  'PROP'=>'Class_Name_Ex()',
                  'INLINE'=>'Class_Name_Ex ( void ) - Returns The Class Name Ex Of The Selected Object.',
                  );
				  
	

				  










				  

				  

return $result;