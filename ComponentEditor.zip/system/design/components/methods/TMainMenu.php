<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('addItem'),
                  'PROP'=>'addItem',
                  'INLINE'=>'addItem( TMenuItem item )',
                  );

return $result;