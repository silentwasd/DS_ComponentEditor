<? $result =array(); $result[] =array( 'CAPTION'=>t('setFocus'), 'PROP'=>'setFocus()', 'INLINE'=>'setFocus ( void )', );$result[] =array( 'CAPTION'=>t('Set date'), 'PROP'=>'setDate()', 'INLINE'=>'setDate ( void )', );$result[] =array( 'CAPTION'=>t('Set time'), 'PROP'=>'setTime()', 'INLINE'=>'setTime ( void )', );$result[] =array( 'CAPTION'=>t('Show'), 'PROP'=>'show()', 'INLINE'=>'show ( void )', );$result[] =array( 'CAPTION'=>t('Hide'), 'PROP'=>'hide()', 'INLINE'=>'hide ( void )', );$result[] =array( 'CAPTION'=>t('To back'), 'PROP'=>'toBack()', 'INLINE'=>'toBack ( void )', );$result[] =array( 'CAPTION'=>t('To front'), 'PROP'=>'toFront()', 'INLINE'=>'toFront ( void )', );$result[] =array( 'CAPTION'=>t('Invalidate'), 'PROP'=>'invalidate()', 'INLINE'=>'invalidate ( void )', );$result[] =array( 'CAPTION'=>t('Repaint'), 'PROP'=>'repaint()', 'INLINE'=>'repaint ( void )', );$result[] =array( 'CAPTION'=>t('Perform'), 'PROP'=>'perform', 'INLINE'=>'perform ( string msg, int hparam, int lparam )', );$result[] =array( 'CAPTION'=>t('Create'), 'PROP'=>'create', 'INLINE'=>'create ( [object parent = activeForm] )', );$result[] =array( 'CAPTION'=>t('Free'), 'PROP'=>'free()', 'INLINE'=>'free ( void )', );return $result;
/*
    
$$$$$___$$$$$___$$$$$$__$$$$$$__$$$$$___$$$$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$____$$__$$____$$______$$____$$$$____$$__$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$$___$$$$$___$$$$$$____$$____$$$$$___$$$$$

        $$$$$___$$__$$
        $$__$$___$$$$
        $$$$$_____$$
        $$__$$____$$
        $$$$$_____$$

_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$
$$______$$______$$$_$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$____$$_$$$__$$______$$$$$$____$$____$$______$$$$
____$$__$$______$$__$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$

*/