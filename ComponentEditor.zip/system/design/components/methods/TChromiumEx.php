<?
$result = array();

$result[] = array(
	'CAPTION' => 'URL Address',
	'PROP' => 'getAddress()',
	'INLINE' => 'string getAddress ( void )',
);

$result[] = array(
	'CAPTION' => 'goBack',
	'PROP' => 'goBack()',
	'INLINE' => 'goBack ( void )',
);

$result[] = array(
	'CAPTION' => 'canGoBack',
	'PROP' => 'canGoBack()',
	'INLINE' => 'bool canGoBack ( void )',
);

$result[] = array(
	'CAPTION' => 'goForward',
	'PROP' => 'goForward()',
	'INLINE' => 'goForward ( void )',
);

$result[] = array(
	'CAPTION' => 'canGoForward',
	'PROP' => 'canGoForward()',
	'INLINE' => 'bool canGoForward ( void )',
);

$result[] = array(
	'CAPTION' => 'clearHistory',
	'PROP' => 'clearHistory()',
	'INLINE' => 'clearHistory ( void )',
);

$result[] = array(
	'CAPTION' => 'hidePopup',
	'PROP' => 'hidePopup()',
	'INLINE' => 'hidePopup ( void )',
);

$result[] = array(
	'CAPTION' => 'setFocus',
	'PROP' => 'setFocus',
	'INLINE' => 'setFocus ( [bool enable = false] )',
);

$result[] = array(
	'CAPTION' => 'stopLoad',
	'PROP' => 'stopLoad()',
	'INLINE' => 'stopLoad ( void )',
);

$result[] = array(
	'CAPTION' => 'reload',
	'PROP' => 'reload()',
	'INLINE' => 'reload ( void )',
);

$result[] = array(
	'CAPTION' => 'reloadIgnoreCache',
	'PROP' => 'reloadIgnoreCache()',
	'INLINE' => 'reloadIgnoreCache ( void )',
);

$result[] = array(
	'CAPTION' => 'showPrint',
	'PROP' => 'showPrint()',
	'INLINE' => 'showPrint ( void )',
);

$result[] = array(
	'CAPTION' => 'load',
	'PROP' => 'load',
	'INLINE' => 'load ( string url )',
);

$result[] = array(
	'CAPTION' => 'loadString',
	'PROP' => 'loadString',
	'INLINE' => 'loadString ( string str, [string url = "auto:blank"] )',
);

$result[] = array(
	'CAPTION' => 'loadFile',
	'PROP' => 'loadFile',
	'INLINE' => 'loadFile ( string fileName, [string url = "auto:blank"] )',
);

$result[] = array(
	'CAPTION' => 'executeJs',
	'PROP' => 'executeJs',
	'INLINE' => 'executeJs ( string code, [string url = "auto:blank"] )',
);

$result[] = array(
	'CAPTION' => 'sendFocusEvent',
	'PROP' => 'sendFocusEvent',
	'INLINE' => 'sendFocusEvent ( int event )',
);

$result[] = array(
	'CAPTION' => 'sendKeyEvent',
	'PROP' => 'sendKeyEvent',
	'INLINE' => 'sendKeyEvent ( int type, int key, int modifers, int sysChar, int imeChar )',
);

$result[] = array(
	'CAPTION' => 'sendMouseClickEvent',
	'PROP' => 'sendMouseClickEvent',
	'INLINE' => 'sendMouseClickEvent ( int x, int y, int type, int mouseUp, int clickCnt )',
);

$result[] = array(
	'CAPTION' => 'scrollBy',
	'PROP' => 'scrollBy',
	'INLINE' => 'scrollBy ( int x, int y )',
);

$result[] = array(
	'CAPTION' => 'undo',
	'PROP' => 'undo()',
	'INLINE' => 'undo ( void )',
);

$result[] = array(
	'CAPTION' => 'redo',
	'PROP' => 'redo()',
	'INLINE' => 'redo ( void )',
);

$result[] = array(
	'CAPTION' => 'cut',
	'PROP' => 'cut()',
	'INLINE' => 'cut ( void )',
);

$result[] = array(
	'CAPTION' => 'copy',
	'PROP' => 'copy()',
	'INLINE' => 'copy ( void )',
);

$result[] = array(
	'CAPTION' => 'paste',
	'PROP' => 'paste()',
	'INLINE' => 'paste ( void )',
);

$result[] = array(
	'CAPTION' => 'del',
	'PROP' => 'del()',
	'INLINE' => 'del ( void )',
);

$result[] = array(
	'CAPTION' => 'selectAll',
	'PROP' => 'selectAll()',
	'INLINE' => 'selectAll ( void )',
);

$result[] = array(
	'CAPTION' => 'Show',
	'PROP' => 'show()',
	'INLINE' => 'show ( void )',
);

$result[] = array(
	'CAPTION' => 'Hide',
	'PROP' => 'hide()',
	'INLINE' => 'hide ( void )',
);

$result[] = array(
	'CAPTION' => 'To back',
	'PROP' => 'toBack()',
	'INLINE' => 'toBack ( void )',
);

$result[] = array(
	'CAPTION' => 'To front',
	'PROP' => 'toFront()',
	'INLINE' => 'toFront ( void )',
);

$result[] = array(
	'CAPTION' => 'Invalidate',
	'PROP' => 'invalidate()',
	'INLINE' => 'invalidate ( void )',
);

$result[] = array(
	'CAPTION' => 'Repaint',
	'PROP' => 'repaint()',
	'INLINE' => 'repaint ( void )',
);

$result[] = array(
	'CAPTION' => 'Perform',
	'PROP' => 'perform',
	'INLINE' => 'perform ( string msg, int hparam, int lparam )',
);

$result[] = array(
	'CAPTION' => 'Create',
	'PROP' => 'create',
	'INLINE' => 'create ( [object parent = activeForm] )',
);

$result[] = array(
	'CAPTION' => 'Free',
	'PROP' => 'free()',
	'INLINE' => 'free ( void )',
);

return $result;