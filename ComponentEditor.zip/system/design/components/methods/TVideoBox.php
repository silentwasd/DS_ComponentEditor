<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('SetParent_form'),
                  'PROP'=>'SetParent_form()',
                  'INLINE'=>'SetParent_form( )',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Load'),
                  'PROP'=>'Movie_Load()',
                  'INLINE'=>'Movie_Load()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Close'),
                  'PROP'=>'Movie_Close()',
                  'INLINE'=>'Movie_Close()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Play'),
                  'PROP'=>'Movie_Play()',
                  'INLINE'=>'Movie_Play()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Stop'),
                  'PROP'=>'Movie_Stop()',
                  'INLINE'=>'Movie_Stop()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Pause'),
                  'PROP'=>'Movie_Pause()',
                  'INLINE'=>'Movie_Pause()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Resume'),
                  'PROP'=>'Movie_Resume()',
                  'INLINE'=>'Movie_Resume()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetSeek'),
                  'PROP'=>'Movie_GetSeek()',
                  'INLINE'=>'Movie_GetSeek()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_Seek'),
                  'PROP'=>'Movie_Seek()',
                  'INLINE'=>'Movie_Seek()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetVolume'),
                  'PROP'=>'Movie_GetVolume()',
                  'INLINE'=>'Movie_GetVolume()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_SetVolume'),
                  'PROP'=>'Movie_SetVolume()',
                  'INLINE'=>'Movie_SetVolume()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetLength'),
                  'PROP'=>'Movie_GetLength()',
                  'INLINE'=>'Movie_GetLength()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetZoom'),
                  'PROP'=>'Movie_GetZoom()',
                  'INLINE'=>'Movie_GetZoom()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_SetZoom'),
                  'PROP'=>'Movie_SetZoom()',
                  'INLINE'=>'Movie_SetZoom()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetSize'),
                  'PROP'=>'Movie_GetSize()',
                  'INLINE'=>'Movie_GetSize()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_SetSize'),
                  'PROP'=>'Movie_SetSize',
                  'INLINE'=>'Movie_SetSize()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetPosition'),
                  'PROP'=>'Movie_GetPosition()',
                  'INLINE'=>'Movie_GetPosition()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_SetPosition'),
                  'PROP'=>'Movie_SetPosition()',
                  'INLINE'=>'Movie_SetPosition()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_GetRepeat'),
                  'PROP'=>'Movie_GetRepeat()',
                  'INLINE'=>'Movie_GetRepeat()',
                  );

$result[] = array(
                  'CAPTION'=>t('Movie_SetRepeat'),
                  'PROP'=>'Movie_SetRepeat()',
                  'INLINE'=>'Movie_SetRepeat()',
                  );

$result[] = array(
                  'CAPTION'=>t('setFocus'),
                  'PROP'=>'setFocus()',
                  'INLINE'=>'setFocus ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('Show'),
                  'PROP'=>'show()',
                  'INLINE'=>'show ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('Hide'),
                  'PROP'=>'hide()',
                  'INLINE'=>'hide ( void )',
                  );


$result[] = array(
                  'CAPTION'=>t('To back'),
                  'PROP'=>'toBack()',
                  'INLINE'=>'toBack ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('To front'),
                  'PROP'=>'toFront()',
                  'INLINE'=>'toFront ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('Invalidate'),
                  'PROP'=>'invalidate()',
                  'INLINE'=>'invalidate ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('Repaint'),
                  'PROP'=>'repaint()',
                  'INLINE'=>'repaint ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('Perform'),
                  'PROP'=>'perform',
                  'INLINE'=>'perform ( string msg, int hparam, int lparam )',
                  );

$result[] = array(
                  'CAPTION'=>t('Create'),
                  'PROP'=>'create',
                  'INLINE'=>'create ( [object parent = activeForm] )',
                  );

$result[] = array(
                  'CAPTION'=>t('Free'),
                  'PROP'=>'free()',
                  'INLINE'=>'free ( void )',
                  );
return $result;