<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('showAuth'),
                  'PROP'=>'showAuth()',
                  'INLINE'=>'showAuth ( void )',
                  );
return $result;