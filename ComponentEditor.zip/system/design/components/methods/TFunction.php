<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('isWorking'),
                  'PROP'=>'isWorking()',
                  'INLINE'=>'bool isWorking ( void )',
                  );

$result[] = array(
                  'CAPTION'=>t('stop'),
                  'PROP'=>'stop()',
                  'INLINE'=>'stop ( void )',
                  );

return $result;