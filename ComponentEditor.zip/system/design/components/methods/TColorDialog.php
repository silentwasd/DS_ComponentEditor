<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('execute'),
                  'PROP'=>'execute()',
                  'INLINE'=>'boolean execute( void )',
                  );

return $result;