<?

$result = array();

$result[] = array(
                  'CAPTION'=>'Active',
                  'PROP'=>'active();',
                  'INLINE'=>'string active ( void )',
                  );

$result[] = array(
                  'CAPTION'=>'UnActive',
                  'PROP'=>'unactive();',
                  'INLINE'=>'string unactive ( void )',
                  );

$result[] = array(
                  'CAPTION'=>'Up',
                  'PROP'=>'Up()',
                  'INLINE'=>'string Up( void )',
                  );

$result[] = array(
                  'CAPTION'=>'Down',
                  'PROP'=>'Down()',
                  'INLINE'=>'string Down( void )',
                  );

return $result;

?>