<?

$result = array();

 
$result[] = array(
                  'CAPTION'=>'To back',
                  'PROP'=>'toBack()',
                  'INLINE'=>'toBack ( void )',
                  );

$result[] = array(
                  'CAPTION'=>'To front',
                  'PROP'=>'toFront()',
                  'INLINE'=>'toFront ( void )',
                  );

$result[] = array(
                  'CAPTION'=>'Free',
                  'PROP'=>'free()',
                  'INLINE'=>'free ( void )',
                  );
return $result;