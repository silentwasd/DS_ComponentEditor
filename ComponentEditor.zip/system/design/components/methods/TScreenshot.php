<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('Создать скриншот'),
                  'PROP'=>'makeScreenshot()',
                  'INLINE'=>'makeScreenshot ( string pathToSave )',
                  );
return $result;