<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('setConstList'),
                  'PROP'=>'setConstList',
                  'INLINE'=>'setConstList ( array names [, int begin = 1] )',
                  );


return $result;