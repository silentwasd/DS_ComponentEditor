<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('showBalloonTip'),
                  'PROP'=>'showBalloonTip()',
                  'INLINE'=>'showBalloonTip ( void )',
                  );
$result[] = array(
                  'CAPTION'=>t('hideBalloonTip'),
                  'PROP'=>'hideBalloonTip()',
                  'INLINE'=>'hideBalloonTip ( void )',
                  );

return $result;