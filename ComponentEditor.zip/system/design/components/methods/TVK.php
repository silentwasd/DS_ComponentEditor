<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Auth'),
                  'PROP'=>'Auth',
                  'INLINE'=>'Auth ( void )',
                  );
$result[] = array(
				  'CAPTION'=>t('SendAsync'),
                  'PROP'=>'SendAsync',
                  'INLINE'=>'SendAsync ( $Method, $Parameters, $Callback )',
                  );
$result[] = array(
				  'CAPTION'=>t('Send'),
                  'PROP'=>'Send',
                  'INLINE'=>'Send ( $Method, $Parameters )',
                  );
$result[] = array(
				  'CAPTION'=>t('CheckSession'),
                  'PROP'=>'CheckSession',
                  'INLINE'=>'CheckSession ( $sid )',
                  );
$result[] = array(
				  'CAPTION'=>t('Save'),
                  'PROP'=>'Save',
                  'INLINE'=>'Save ( $sid )',
                  );
$result[] = array(
				  'CAPTION'=>t('Load'),
                  'PROP'=>'Load',
                  'INLINE'=>'Load ($sid )',
                  );
				  
$result[] = array(
				  'CAPTION'=>t('GetPath'),
                  'PROP'=>'GetPath',
                  'INLINE'=>'GetPath ( $sid )',
                  );
				  
$result[] = array(
				  'CAPTION'=>t('Exists'),
                  'PROP'=>'Exists',
                  'INLINE'=>'Exists ( $sid )',
                  );
$result[] = array(
				  'CAPTION'=>t('IsAuth'),
                  'PROP'=>'IsAuth',
                  'INLINE'=>'IsAuth ( void )',
                  );
$result[] = array(
				  'CAPTION'=>t('GetAccessToken'),
                  'PROP'=>'GetAccessToken',
                  'INLINE'=>'GetAccessToken ( void )',
                  );
$result[] = array(
				  'CAPTION'=>t('GetUserId'),
                  'PROP'=>'GetUserId',
                  'INLINE'=>'GetUserId ( void )',
                  );
$result[] = array(
				  'CAPTION'=>t('GetExpiresIn'),
                  'PROP'=>'GetExpiresIn',
                  'INLINE'=>'GetExpiresIn ( void )',
                  );


return $result;

?>