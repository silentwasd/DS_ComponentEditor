<?

$result = array();



$result[] = array(
                  'CAPTION'=>t('execute'),
                  'PROP'=>'execute()',
                  'INLINE'=>'mixed execute( void )',
                  );

return $result;