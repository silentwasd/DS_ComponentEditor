<?

$result = array();

$result['GROUP']   = 'dialogs';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Print Dialog');
$result['SORT']    = 1099;
$result['NAME']    = 'printDlg';

return $result;