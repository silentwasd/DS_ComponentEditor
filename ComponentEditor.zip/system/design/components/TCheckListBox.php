<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TCheckListBox_Caption');
$result['SORT']    = 480;
$result['NAME']    = 'checkList';
$result['W']       = 20;
$result['H']       = 20;

return $result;