<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TVideoBox');
$result['SORT']    = 450;
$result['NAME']    = 'videoBox';
$result['WINCONTROL'] = true;
$result['DLLS'] = array('video.dll', 'xMovie.dll');
$result['W'] = 20;
$result['H'] = 15;

return $result;