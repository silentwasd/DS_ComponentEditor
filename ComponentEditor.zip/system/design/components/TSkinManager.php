<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Skin Manager');
$result['SORT']    = 1;
$result['NAME']    = 'skinManager';

return $result;