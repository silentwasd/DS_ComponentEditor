<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TImage_Caption');
$result['SORT']    = 235;

$result['NAME']    = 'image';

$result['W'] = 20;
$result['H'] = 15;

return $result;