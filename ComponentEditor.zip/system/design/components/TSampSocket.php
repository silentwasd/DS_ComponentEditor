<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'TSampSocket';
$result['SORT']    = 613;
$result['NAME']    = 'TSampSocket';

return $result;

?>