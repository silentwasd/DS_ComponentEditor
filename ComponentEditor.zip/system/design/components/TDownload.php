<?

$result = array();

$result['GROUP']   = 'internet';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TDownload_Caption');
$result['SORT']    = 2020;
$result['NAME']    = 'download';

return $result;