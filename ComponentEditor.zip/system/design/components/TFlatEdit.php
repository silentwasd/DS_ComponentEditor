<?

/* Компонент TFlatEdit - плоская версия TEdit
Автор компонента: Ваня Стасевич (Дима Скрипов) (vk.com/mrcloudcraft)
Версия компонента: 1.3

vk.com/copersoft
*/

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Flat Edit');
$result['SORT']    = 1;
$result['NAME']    = 'flatEdit';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 16;
$result['H'] = 3;

return $result;