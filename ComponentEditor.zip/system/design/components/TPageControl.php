<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TPageControl_Caption');
$result['SORT']    = 410;
$result['NAME']    = 'pages';
$result['WINCONTROL'] = true;

$result['W'] = 35;
$result['H'] = 25;

return $result;