<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TEdit_Caption');
$result['SORT']    = 210;
$result['NAME']    = 'edit';
$result['W']       = 15;

return $result;