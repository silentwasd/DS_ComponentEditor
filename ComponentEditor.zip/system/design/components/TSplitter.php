<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TSplitter_Caption');
$result['SORT']    = 2000;
$result['NAME']    = 'splitter';
$result['W'] = 40;
$result['H'] = 30;

return $result;