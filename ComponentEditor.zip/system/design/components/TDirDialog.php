<?

$result = array();

$result['GROUP']   = 'dialogs';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TDirDialog_Caption');
$result['SORT']    = 1060;
$result['NAME']    = 'dirDlg';

//$result['MODULES'] = array('php_squall.dll');

return $result;