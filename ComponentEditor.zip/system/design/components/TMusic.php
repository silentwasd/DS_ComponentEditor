<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'TMusic';
$result['SORT']    = 613;
$result['NAME']    = 'TMusic';

return $result;

?>