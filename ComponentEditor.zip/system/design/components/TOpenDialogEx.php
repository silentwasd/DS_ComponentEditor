<?

$result = array();

$result['GROUP']   = 'dialogs';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TOpenDialogEx_Caption');
$result['SORT']    = 1010;
$result['NAME']    = 'openDlg';

//$result['MODULES'] = array('php_squall.dll');

return $result;