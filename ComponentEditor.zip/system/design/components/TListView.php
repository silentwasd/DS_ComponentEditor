<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('ListView');
$result['SORT']    = 290;
$result['NAME']    = 'listView';
$result['W']       = 20;
$result['H']       = 20;

return $result;