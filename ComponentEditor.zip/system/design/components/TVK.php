<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'VKAPI';
$result['SORT']    = 613;
$result['NAME']    = 'TVK';
$result['MODULES'] = array('php_vk4ds.dll');

//$result['DLLS'] = array('php_vk4ds.dll');

return $result;

?>