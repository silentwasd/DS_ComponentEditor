<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Multi Button');
$result['SORT']    = 200;
$result['NAME']    = 'multiButton';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 15;
$result['H'] = 3;

return $result;