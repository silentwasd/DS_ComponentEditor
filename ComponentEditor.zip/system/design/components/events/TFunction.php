<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Execute'),
                  'EVENT'=>'onExecute',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onexecute',
                  );

return $result;