<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('On Show'),
                  'EVENT'=>'onShow',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onshow',
                  );
$result[] = array(
                  'CAPTION'=>t('On Close'),
                  'EVENT'=>'onClose',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onclose',
                  );
$result[] = array(
                  'CAPTION'=>t('onReplace'),
                  'EVENT'=>'onReplace',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onreplace',
                  );
return $result;