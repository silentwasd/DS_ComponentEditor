<?

//**************************************************//
//********************ProgressBarEx2.2**************//
//********************By Roman**********************//
//**************************************************//

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Mouse Enter'),
                  'EVENT'=>'onMouseEnter',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onmouseenter',
                  );

return $result;