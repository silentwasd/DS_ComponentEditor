<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Drop Files'),
                  'EVENT'=>'onDropFiles',
                  'INFO'=>'%func%($self,$files)',
                  'ICON'=>'ondropfiles',
                  );
return $result;