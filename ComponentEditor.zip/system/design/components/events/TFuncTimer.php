<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Timer'),
                  'EVENT'=>'onTimer',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'ontimer',
                  );

return $result;