<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Select'),
                  'EVENT'=>'onSelect',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onselect',
                  );
return $result;