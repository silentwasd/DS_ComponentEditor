<?
$result = array();

$result[] = array(
	'CAPTION' => 'On Chromium Lib Load',
	'EVENT' => 'onchromiumlibload',
	'INFO' => '%func%($self)',
	'ICON' => 'onchromiumlibload'
);

$result[] = array(
	'CAPTION' => 'On Before Browse',
	'EVENT' => 'onbeforebrowse',
	'INFO' => '%func%($self, $url, $method, $type, $redirect, &$continue)',
	'ICON' => 'onbeforebrowse'
);

$result[] = array(
	'CAPTION' => 'On Before Popup',
	'EVENT' => 'onbeforepopup',
	'INFO' => '%func%()',
	'ICON' => 'onbeforepopup'
);

$result[] = array(
	'CAPTION' => 'On Before Menu',
	'EVENT' => 'onbeforemenu',
	'INFO' => '%func%()',
	'ICON' => 'onbeforemenu'
);

$result[] = array(
	'CAPTION' => 'On Auth Credentials',
	'EVENT' => 'onauthcredentials',
	'INFO' => '%func%()',
	'ICON' => 'onauthcredentials'
);

$result[] = array(
	'CAPTION' => 'On Get Download Handler',
	'EVENT' => 'ongetdownloadhandler',
	'INFO' => '%func%()',
	'ICON' => 'ongetdownloadhandler'
);

$result[] = array(
	'CAPTION' => 'On Console Message',
	'EVENT' => 'onconsolemessage',
	'INFO' => '%func%()',
	'ICON' => 'onconsolemessage'
);

$result[] = array(
	'CAPTION' => 'On Load Start',
	'EVENT' => 'onloadstart',
	'INFO' => '%func%()',
	'ICON' => 'onloadstart'
);

$result[] = array(
	'CAPTION' => 'On Load End',
	'EVENT' => 'onloadend',
	'INFO' => '%func%()',
	'ICON' => 'onloadend'
);

$result[] = array(
	'CAPTION' => 'On Load Error',
	'EVENT' => 'onloaderror',
	'INFO' => '%func%()',
	'ICON' => 'onloaderror'
);

$result[] = array(
	'CAPTION' => 'On Address Change',
	'EVENT' => 'onaddresschange',
	'INFO' => '%func%()',
	'ICON' => 'onaddresschange'
);

$result[] = array(
	'CAPTION' => 'On Title Change',
	'EVENT' => 'ontitlechange',
	'INFO' => '%func%()',
	'ICON' => 'ontitlechange'
);

return $result;