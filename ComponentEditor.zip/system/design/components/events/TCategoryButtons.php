<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('On Button Clicked'),
                  'EVENT'=>'onButtonClicked',
                  'INFO'=>'%func%($self)',
                  'ICON'=>'onclick',
                  );

return $result;