<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TMaskEdit_Caption');
$result['SORT']    = 210;
$result['NAME']    = 'maskEdit';
$result['W']       = 15;

return $result;