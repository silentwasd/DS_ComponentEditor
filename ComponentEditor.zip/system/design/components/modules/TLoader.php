<?


class TLoader extends TMImage {
    
    public $class_name_ex = __CLASS__;
    
    public function __construct($onwer=nil,$init=true,$self=nil){
        parent::__construct($onwer, $init, $self);
        
        if ( $init ){
	  $this->autoSize = true;
	  $this->visible = true;
	  $this->loadFromFile("../system/images/gifs/1.GIF");
	}
    }
    
    public function __initComponentInfo(){
        
        parent::__initComponentInfo();
	
	if ( $this->select == '1' ){
		$this->loadFromFile("../system/images/gifs/1.GIF");
	} elseif ( $this->select == '2' ){
		$this->loadFromFile("../system/images/gifs/2.GIF");
	}
    }
}