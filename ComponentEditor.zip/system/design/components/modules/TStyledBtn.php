<?
Class TStyledBtn extends TShape {
    
    Public $class_name_ex = __CLASS__;
    
	 Public Function __inspectProperties()
	{
	
		return true;
	 }
    
	 Public Function __initComponentInfo()
	{
		parent::__initComponentInfo();

		/*$this->penColor = clGrey;
		$this->brushColor = clBlack;
		$this->penWidth = 1;*/

                                $this->penColor =  $this->myPenColor;
                                $this->brushColor =  $this->myBrushColor;
                                $this->penWidth = $this->myPenWidth;
	 }

                Public Function active(){ $this->brushColor = $this->leaveColor; }
                Public Function unactive(){ $this->brushColor = $this->myBrushColor; }
                Public Function Up(){
                          $this->brushColor = $this->leaveColor;
                          $this->penWidth = $this->myPenWidth;
                }
                Public Function Down(){
                          $this->brushColor = $this->myClickColor;
                          $this->penWidth = $this->myPenWidthLeave;
                }
    
	Public Function __construct($onwer=nil,$init=true,$self=nil)
	{
		parent::__construct($onwer, $init, $self);
		
                                $this->penColor =  $this->myPenColor;
                                $this->brushColor =  $this->myBrushColor;
                                $this->penWidth = $this->myPenWidth;

                                $obj = $this;
                                $this->onMouseEnter = function()use($obj){
                                            $obj->brushColor = $obj->leaveColor;
                                };

                                $this->onMouseLeave = function()use($obj){
                                            $obj->brushColor = $obj->myBrushColor;
                                };

                                $this->onMouseDown = function()use($obj){
                                            $obj->brushColor = $obj->myClickColor;
                                            $obj->penWidth = $obj->myPenWidthLeave;
                                };

                                $this->onMouseUp = function()use($obj){
                                            $obj->brushColor = $obj->leaveColor;
                                            $obj->penWidth = $obj->myPenWidth;
                                };
	 }
}
?>