<? define(_base64_decode_, 0); define(_base64_encode_, 1); define(_gzcompress_, 2); define(_gzuncompress_, 3); define(_unserialize_, 4); define(_serialize_, 5); Class TDE Extends __TNoVisual{ public $class_name_ex =__CLASS__; public Function __construct($owner=nil,$init=true,$self=nil){ parent::__construct($owner,$init,$self); if ($init){ $this->type =_base64_decode_; }}function ec(){ if(!$this->data) return false; switch($this->type){ case _base64_decode_: $data =base64_decode($this->data); break; case _base64_encode_: $data =base64_encode($this->data); break; case _gzcompress_: $data =gzcompress($this->data, 9); break; case _gzuncompress_: $data =gzuncompress($this->data); break; case _serialize_: $this->serialize =false; $data =serialize($this->data); break; case _unserialize_: $this->serialize =false; $data =unserialize($this->data); break; default: return $data; break; }if(!$data) return false; return !$this->serialize ?$data :serialize($data); }}
/*
    
$$$$$___$$$$$___$$$$$$__$$$$$$__$$$$$___$$$$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$____$$__$$____$$______$$____$$$$____$$__$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$$___$$$$$___$$$$$$____$$____$$$$$___$$$$$

        $$$$$___$$__$$
        $$__$$___$$$$
        $$$$$_____$$
        $$__$$____$$
        $$$$$_____$$

_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$
$$______$$______$$$_$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$____$$_$$$__$$______$$$$$$____$$____$$______$$$$
____$$__$$______$$__$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$

*/