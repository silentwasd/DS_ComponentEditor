<?
Class TUIButton extends TPanel 
{
    Public $class_name_ex = __CLASS__;
    Public $objects;
    
    Public Function __inspectProperties()
	{
	   return true;
    }
    
    Public Function __initComponentInfo()
	{
        parent::__initComponentInfo();
        $this->bevelInner = bvNone;
        $this->bevelOuter = bvNone;
        $this->update();
    }
    
	Public Function __construct($onwer=nil,$init=true,$self=nil)
	{
        parent::__construct($onwer, $init, $self);
        
        if( $init )
        {
            if ( !$GLOBALS['APP_DESIGN_MODE'] )
            $this->__initComponentInfo();
            $this->def_color = 0x0020002;
            $this->uipack = 'default.uip';
            $this->uiname = 'Green';
            $this->dyn_label = True;
            $this->shadow = True;
            $this->inner_shadow = False;
            $this->stroke = False;
            $this->default_pack = False;
            $this->font_size = 8;
            $this->inner_shadow_color = $this->def_color;
            $this->shadow_color = $this->def_color;
            $this->label_color = $this->def_color;
            $this->stroke_color = $this->def_color;
        }
        
        IF( $this->default_pack )
        {
            self::__CreateDefaultPack();
        }
        
        $this->__reDraw();
    }

    Public Static Function __CreateDefaultPack()
    {
        IF( !file_exists($GLOBALS['progDir'].'default.uip') ){
            $pack = 'UEsDBAoAAAAAADpJWD4AAAAAAAAAAAAAAAANAAAAQnV0dG9uX0dyZWVuL1BLAwQUAAIACADFSFg+coMlpwwBAAASAQAAGAAAAEJ1dHRvbl9HcmVlbi9DZW50ZXIxLnBuZ+sM8HPn5ZLiYmBg4PX0cAkC0iC2HAcTkJwlLpEOpDgLPCKLGRj4DoMw4/H8FSlAQcbiIHcnhnXnZF4COSzpjr6ODAwb+7n/JLIC+QrJHkG+DAxVagwMDS0MDL+AQg0vGBhKDRgYXiUwMFjNYGAQL5izK9AGKFHt6eIYYuH/9oK74CEGBtaLrixsFo8ZOFusSnYIV/WymiQo9Kp0OEiyzQg9ML/89/a1W/t4U86fdxbYG960Iorr3VWnAu3nTdmWwjFdKx/E+LAsvx5RcMa9ydlO5M3mxoTpX1lvb1G/sST2oNpLjkMqAi2FChHHcz/urz+20HJFtz5P2oSmLdz2lUBnMHi6+rmsc0poAgBQSwMEFAACAAgAxUhYPnKDJacMAQAAEgEAABgAAABCdXR0b25fR3JlZW4vQ2VudGVyMi5wbmfrDPBz5+WS4mJgYOD19HAJAtIgthwHE5CcJS6RDqQ4CzwiixkY+A6DMOPx/BUpQEHG4iB3J4Z152ReAjks6Y6+jgwMG/u5/ySyAvkKyR5BvgwMVWoMDA0tDAy/gEINLxgYSg0YGF4lMDBYzWBgEC+YsyvQBihR7eniGGLh//aCu+AhBgbWi64sbBaPGThbrEp2CFf1spokKPSqdDhIss0IPTC//Pf2tVv7eFPOn3cW2BvetCKK691VpwLt503ZlsIxXSsfxPiwLL8eUXDGvcnZTuTN5saE6V9Zb29Rv7Ek9qDaS45DKgIthQoRx3M/7q8/ttByRbc+T9qEpi3c9pVAZzB4uvq5rHNKaAIAUEsDBBQAAgAIAC9JWD5tOz25tQAAAL8AAAAYAAAAQnV0dG9uX0dyZWVuL0NlbnRlcjMucG5n6wzwc+flkuJiYGDg9fRwCQLSILYcBxOQnCUukQ6kOAs8IosZGPgOgzDj8fwVKUBBxuIgdyeGdedkXgI5LOmOvo4MDBv7uf8ksgL5CskeQb4MDFVqDAwNLQwMv4BCDS8YGEoNGBheJTAwWM1gYBAvmLMr0AYooeHp4hhi4Z+85Vxw0gFmobRdDx15Fl+6cSjdJGLDsu6LCQfldA7odLAzMqR5p25yVzy6AaiHwdPVz2WdU0ITAFBLAwQUAAIACACxSFg+9Zmp8w4BAAAPAQAAFgAAAEJ1dHRvbl9HcmVlbi9MZWZ0MS5wbmfrDPBz5+WS4mJgYOD19HAJAtIgthwHE5CcJS6RDqQYi4PcnRjWnZN5CeSwpDv6OjIwbOzn/pPICuQrJHsE+TIwVKkxMDS0MDD8Ago1vGBgKDVgYHiVwMBgNYOBQbxgzq5AG6BEr6eLY4iF/9sLO0WbAhhcAnUOsXW8PSDkwtq/+8kjtnW6Ecy8G5pdI2ae6a8NezBn9t4cq78XttWtOfvxt+caM/s4O8OdNwWeVm9WO7W9ynXK+q+TNOJXsQbahRcvkplqvEhGLHhRjZaay88Z1S4/J+x2qZzf2/lJT1pw8mXFQL6g9hlzLFwqZ/OcsK+vddv+ZY/eT4ZrLvVdmw1vngY6jMHT1c9lnVNCEwBQSwMEFAACAAgAsUhYPvWZqfMOAQAADwEAABYAAABCdXR0b25fR3JlZW4vTGVmdDIucG5n6wzwc+flkuJiYGDg9fRwCQLSILYcBxOQnCUukQ6kGIuD3J0Y1p2TeQnksKQ7+joyMGzs5/6TyArkKyR7BPkyMFSpMTA0tDAw/AIKNbxgYCg1YGB4lcDAYDWDgUG8YM6uQBugRK+ni2OIhf/bCztFmwIYXAJ1DrF1vD0g5MLav/vJI7Z1uhHMvBuaXSNmnumvDXswZ/beHKu/F7bVrTn78bfnGjP7ODvDnTcFnlZvVju1vcp1yvqvkzTiV7EG2oUXL5KZarxIRix4UY2WmsvPGdUuPyfsdqmc39v5SU9acPJlxUC+oPYZcyxcKmfznLCvr3Xb/mWP3k+Gay71XZsNb54GOozB09XPZZ1TQhMAUEsDBBQAAgAIABVJWD6mXY0KtgAAAMAAAAAWAAAAQnV0dG9uX0dyZWVuL0xlZnQzLnBuZ+sM8HPn5ZLiYmBg4PX0cAkC0iC2HAcTkJwlLpEOpDgLPCKLGRj4DoMw4/H8FSlAQcbiIHcnhnXnZF4COSzpjr6ODAwb+7n/JLIC+QrJHkG+DAxVagwMDS0MDL+AQg0vGBhKDRgYXiUwMFjNYGAQL5izK9AGKKHp6eIYYuGfvOVccNIB5oZLnMZ3CxTbAjNzGo2ldCKEz2RseMAjlmB3qJVh7flIJjWF69+Bmhg8Xf1c1jklNAEAUEsDBBQAAgAIANVIWD7lh9lRIgEAACUBAAAXAAAAQnV0dG9uX0dyZWVuL1JpZ2h0MS5wbmfrDPBz5+WS4mJgYOD19HAJAtIgthwHE5CcJS6RDqQ4CzwiixkY+A6DMOPx/BUpQEHG4iB3J4Z152ReAjks6Y6+jgwMG/u5/ySyAvkKyR5BvgwMVWoMDA0tDAy/gEINLxgYSg0YGF4lMDBYzWBgEC+YsyvQBijR5+niGGLh//bCccGmBBHXRN0mtpjbjaoMWnxabXsle3QjmnknqIg4plb939rOVfP57bk9Z9/yHYpb/jTu7OQXnwPXd5682qVxf7Vq4L6p3ItqdJkX1Wg+c/kZc6aj6Ms8oacG3zs/ac4XeJr8TPCps5naqd8lLlPKX06YMWeHS+VsiyNPbiiemn1D7f+fYsmzl77rfDorv6CrvuuX9PPdQJcxeLr6uaxzSmgCAFBLAwQUAAIACADVSFg+5YfZUSIBAAAlAQAAFwAAAEJ1dHRvbl9HcmVlbi9SaWdodDIucG5n6wzwc+flkuJiYGDg9fRwCQLSILYcBxOQnCUukQ6kOAs8IosZGPgOgzDj8fwVKUBBxuIgdyeGdedkXgI5LOmOvo4MDBv7uf8ksgL5CskeQb4MDFVqDAwNLQwMv4BCDS8YGEoNGBheJTAwWM1gYBAvmLMr0AYo0efp4hhi4f/2wnHBpgQR10TdJraY242qDFp8Wm17JXt0I5p5J6iIOKZW/d/azlXz+e25PWff8h2KW/407uzkF58D13eevNqlcX+1auC+qdyLanSZF9VoPnP5GXOmo+jLPKGnBt87P2nOF3ia/EzwqbOZ2qnfJS5Tyl9OmDFnh0vlbIsjT24onpp9Q+3/n2LJs5e+63w6K7+gq77rl/Tz3UCXMXi6+rmsc0poAgBQSwMEFAACAAgAOklYPiSEdjq1AAAAvwAAABcAAABCdXR0b25fR3JlZW4vUmlnaHQzLnBuZ+sM8HPn5ZLiYmBg4PX0cAkC0iC2HAcTkJwlLpEOpDgLPCKLGRj4DoMw4/H8FSlAQcbiIHcnhnXnZF4COSzpjr6ODAwb+7n/JLIC+QrJHkG+DAxVagwMDS0MDL+AQg0vGBhKDRgYXiUwMFjNYGAQL5izK9AGKKHh6eIYYuGfvOVccNIBZqG0XQ+dFOYuviTx0FhKJ0L4aMaGBzxiCRceODKw1EYyTXhYcACoh8HT1c9lnVNCEwBQSwMEFAAAAAgA0YVYPjgP9nISAAAAFQAAABAAAABCdXR0b25fR3JlZW4vLnVpMzawNqgwMDIyczV2ArLSwAAAUEsBAhQACgAAAAAAOklYPgAAAAAAAAAAAAAAAA0AAAAAAAAAAAAQAAAAAAAAAEJ1dHRvbl9HcmVlbi9QSwECFAAUAAIACADFSFg+coMlpwwBAAASAQAAGAAAAAAAAAAAACAgAAArAAAAQnV0dG9uX0dyZWVuL0NlbnRlcjEucG5nUEsBAhQAFAACAAgAxUhYPnKDJacMAQAAEgEAABgAAAAAAAAAAAAgAAAAbQEAAEJ1dHRvbl9HcmVlbi9DZW50ZXIyLnBuZ1BLAQIUABQAAgAIAC9JWD5tOz25tQAAAL8AAAAYAAAAAAAAAAAAICAAAK8CAABCdXR0b25fR3JlZW4vQ2VudGVyMy5wbmdQSwECFAAUAAIACACxSFg+9Zmp8w4BAAAPAQAAFgAAAAAAAAAAACAgAACaAwAAQnV0dG9uX0dyZWVuL0xlZnQxLnBuZ1BLAQIUABQAAgAIALFIWD71manzDgEAAA8BAAAWAAAAAAAAAAAAIAAAANwEAABCdXR0b25fR3JlZW4vTGVmdDIucG5nUEsBAhQAFAACAAgAFUlYPqZdjQq2AAAAwAAAABYAAAAAAAAAAAAgIAAAHgYAAEJ1dHRvbl9HcmVlbi9MZWZ0My5wbmdQSwECFAAUAAIACADVSFg+5YfZUSIBAAAlAQAAFwAAAAAAAAAAACAgAAAIBwAAQnV0dG9uX0dyZWVuL1JpZ2h0MS5wbmdQSwECFAAUAAIACADVSFg+5YfZUSIBAAAlAQAAFwAAAAAAAAAAACAAAABfCAAAQnV0dG9uX0dyZWVuL1JpZ2h0Mi5wbmdQSwECFAAUAAIACAA6SVg+JIR2OrUAAAC/AAAAFwAAAAAAAAAAACAgAAC2CQAAQnV0dG9uX0dyZWVuL1JpZ2h0My5wbmdQSwECFAAUAAAACADRhVg+OA/2chIAAAAVAAAAEAAAAAAAAAABACAAAACgCgAAQnV0dG9uX0dyZWVuLy51aVBLBQYAAAAACwALAOYCAADgCgAAAAA=';
            @file_put_contents($GLOBALS['progDir'].'default.uip', base64_decode($pack));
        }
    }
    
    Public Function __getImage( $t, $i = 1 )
    {
        IF( File_Exists( $this->uipack ) And is_File( $this->uipack ) )
        {
            $Pack = new ZipArchive();
            @$Pack->open( $GLOBALS['progDir'].$this->uipack );
            $Image = @$Pack->getFromName("Button_".$this->uiname."/".$t.$i.".png");
            $path = $GLOBALS['progDir'].$t.$i.".png";
            file_put_contents($path, $Image);
            return $path;
        }
    }        
 
    Public Function __getSets()
    {
        IF( File_Exists( $this->uipack ) And is_File( $this->uipack ) )
        {
            $Pack = new ZipArchive();
            @$Pack->open( $GLOBALS['progDir'].$this->uipack );
            return explode(';', @$Pack->getFromName("Button_".$this->uiname."/.ui"));
        }
    }
    
	Public Function __reDraw()
    {
        if( !isset($GLOBALS['ui'][$this->self]) )
        {
            $IMAGE1 = $this->__getImage("Left");
            $IMAGE2 = $this->__getImage("Center");
            $IMAGE3 = $this->__getImage("Right");
            $Sets = $this->__getSets();
            $GLOBALS['ui'][$this->self]['image_Left'] = New TMImage();
            $GLOBALS['ui'][$this->self]['image_Left']->name = md5("Left".$this->self);
            $GLOBALS['ui'][$this->self]['image_Left']->LoadFromFile( $IMAGE1 );
            $GLOBALS['ui'][$this->self]['image_Left']->align = alLeft;
            $GLOBALS['ui'][$this->self]['image_Left']->autosize = True;
            $GLOBALS['ui'][$this->self]['image_Left']->parent = $this;
            $GLOBALS['ui'][$this->self]['image_Center'] = New TMImage();
            $GLOBALS['ui'][$this->self]['image_Center']->name = md5("Center".$this->self);
            $GLOBALS['ui'][$this->self]['image_Center']->LoadFromFile( $IMAGE2 );
            $GLOBALS['ui'][$this->self]['image_Center']->align = alClient;
            $GLOBALS['ui'][$this->self]['image_Center']->mosaic = True;
            $GLOBALS['ui'][$this->self]['image_Center']->autosize = False;
            $GLOBALS['ui'][$this->self]['image_Center']->parent = $this;
            $GLOBALS['ui'][$this->self]['image_Right'] = New TMImage();
            $GLOBALS['ui'][$this->self]['image_Right']->name = md5("Right".$this->self);
            $GLOBALS['ui'][$this->self]['image_Right']->LoadFromFile( $IMAGE3 );
            $GLOBALS['ui'][$this->self]['image_Right']->align = alRight;
            $GLOBALS['ui'][$this->self]['image_Right']->autosize = True;
            $GLOBALS['ui'][$this->self]['image_Right']->parent = $this;
            self::MassDelete( $IMAGE1, $IMAGE2, $IMAGE3 );

            $GLOBALS['ui'][$this->self]['innerShadow'] = New TLabel();
            $GLOBALS['ui'][$this->self]['innerShadow']->name = md5("innerShadow".$this->self);
            $GLOBALS['ui'][$this->self]['innerShadow']->font->color = $Sets[1];
            $GLOBALS['ui'][$this->self]['innerShadow']->transparent = True;
            $GLOBALS['ui'][$this->self]['innerShadow']->autoSize = False;
            $GLOBALS['ui'][$this->self]['innerShadow']->alignment = taCenter;
            $GLOBALS['ui'][$this->self]['innerShadow']->layout = tlCenter;
            $GLOBALS['ui'][$this->self]['innerShadow']->x = 0;
            $GLOBALS['ui'][$this->self]['innerShadow']->y = 0;
            $GLOBALS['ui'][$this->self]['innerShadow']->parent = $this;

            $GLOBALS['ui'][$this->self]['Stroke'] = New TLabel();
            $GLOBALS['ui'][$this->self]['Stroke']->name = md5("Stroke".$this->self);
            $GLOBALS['ui'][$this->self]['Stroke']->font->color = $Sets[1];
            $GLOBALS['ui'][$this->self]['Stroke']->transparent = True;
            $GLOBALS['ui'][$this->self]['Stroke']->autoSize = False;
            $GLOBALS['ui'][$this->self]['Stroke']->alignment = taCenter;
            $GLOBALS['ui'][$this->self]['Stroke']->layout = tlCenter;
            $GLOBALS['ui'][$this->self]['Stroke']->x = -1;
            $GLOBALS['ui'][$this->self]['Stroke']->y = -1;
            $GLOBALS['ui'][$this->self]['Stroke']->parent = $this;
         
            $GLOBALS['ui'][$this->self]['Shadow'] = New TLabel();
            $GLOBALS['ui'][$this->self]['Shadow']->name = md5("Shadow".$this->self);
            $GLOBALS['ui'][$this->self]['Shadow']->font->color = $Sets[1];
            $GLOBALS['ui'][$this->self]['Shadow']->transparent = True;
            $GLOBALS['ui'][$this->self]['Shadow']->autoSize = False;
            $GLOBALS['ui'][$this->self]['Shadow']->alignment = taCenter;
            $GLOBALS['ui'][$this->self]['Shadow']->layout = tlCenter;
            $GLOBALS['ui'][$this->self]['Shadow']->x = 1;
            $GLOBALS['ui'][$this->self]['Shadow']->y = 1;
            $GLOBALS['ui'][$this->self]['Shadow']->parent = $this;
            
            $GLOBALS['ui'][$this->self]['Caption'] = New TLabel();
            $GLOBALS['ui'][$this->self]['Caption']->name = md5("Caption".$this->self);
            $GLOBALS['ui'][$this->self]['Caption']->font->color = $Sets[2];
            $GLOBALS['ui'][$this->self]['Caption']->transparent = True;
            $GLOBALS['ui'][$this->self]['Caption']->autoSize = False;
            $GLOBALS['ui'][$this->self]['Caption']->alignment = taCenter;
            $GLOBALS['ui'][$this->self]['Caption']->layout = tlCenter;
            $GLOBALS['ui'][$this->self]['Caption']->x = 0;
            $GLOBALS['ui'][$this->self]['Caption']->y = 0;
            $GLOBALS['ui'][$this->self]['Caption']->parent = $this;
                
            $this->doubleBuffered = True;
            $this->parent->doubleBuffered = True;
        }      
        $this->update();       
    }
    
    Public Static Function evHover( $id )
    {
        $IMAGE1 = c($id)->__getImage('Left', 2);
        $IMAGE2 = c($id)->__getImage('Center', 2);
        $IMAGE3 = c($id)->__getImage('Right', 2);
        $GLOBALS['ui'][$id]['image_Left']->LoadFromFile( $IMAGE1 );
        $GLOBALS['ui'][$id]['image_Center']->LoadFromFile( $IMAGE2 );
        $GLOBALS['ui'][$id]['image_Right']->LoadFromFile( $IMAGE3 );
        self::MassDelete( $IMAGE1, $IMAGE2, $IMAGE3 );
    }
    
    Public Static Function evDown( $id )
    {
        $IMAGE1 = c($id)->__getImage('Left', 3);
        $IMAGE2 = c($id)->__getImage('Center', 3);
        $IMAGE3 = c($id)->__getImage('Right', 3);
        $GLOBALS['ui'][$id]['image_Left']->LoadFromFile( $IMAGE1 );
        $GLOBALS['ui'][$id]['image_Center']->LoadFromFile( $IMAGE2 );
        $GLOBALS['ui'][$id]['image_Right']->LoadFromFile( $IMAGE3 );
        self::MassDelete( $IMAGE1, $IMAGE2, $IMAGE3 );
        IF( c($id)->dyn_label ){
            $GLOBALS['ui'][$id]['Stroke']->x = 0;
            $GLOBALS['ui'][$id]['Stroke']->y = 0;
            $GLOBALS['ui'][$id]['Caption']->x = 1;
            $GLOBALS['ui'][$id]['Caption']->y = 1;
            $GLOBALS['ui'][$id]['Shadow']->x = 2;
            $GLOBALS['ui'][$id]['Shadow']->y = 2;
        }
    }
    
    Public Static Function evUp( $id )
    {
        $IMAGE1 = c($id)->__getImage('Left', 1);
        $IMAGE2 = c($id)->__getImage('Center', 1);
        $IMAGE3 = c($id)->__getImage('Right', 1);
        $GLOBALS['ui'][$id]['image_Left']->LoadFromFile( $IMAGE1 );
        $GLOBALS['ui'][$id]['image_Center']->LoadFromFile( $IMAGE2 );
        $GLOBALS['ui'][$id]['image_Right']->LoadFromFile( $IMAGE3 );
        self::MassDelete( $IMAGE1, $IMAGE2, $IMAGE3 );
        IF( c($id)->dyn_label ){
            $GLOBALS['ui'][$id]['Stroke']->x = -1;
            $GLOBALS['ui'][$id]['Stroke']->y = -1;
            $GLOBALS['ui'][$id]['Caption']->x = 0;
            $GLOBALS['ui'][$id]['Caption']->y = 0;
            $GLOBALS['ui'][$id]['Shadow']->x = 1;
            $GLOBALS['ui'][$id]['Shadow']->y = 1;
        }
    }
    
    Public Static Function evLeave( $id )
    {
        self::evUp( $id );
    }
    
    Public Static Function Nothing(){}
    
    Public Function update()
    {
        $Sets = $this->__getSets();
        IF( isset($Sets[0]) And $Sets[0] > 0 ) $this->h = $Sets[0]; 
        $GLOBALS['ui'][$this->self]['innerShadow']->caption = $this->text;
        $GLOBALS['ui'][$this->self]['Stroke']->caption = $this->text;
        $GLOBALS['ui'][$this->self]['Caption']->caption = $this->text;
        $GLOBALS['ui'][$this->self]['Shadow']->caption = $this->text;
        
        $GLOBALS['ui'][$this->self]['innerShadow']->w = $this->w;
        $GLOBALS['ui'][$this->self]['Stroke']->w = $this->w;
        $GLOBALS['ui'][$this->self]['Caption']->w = $this->w;
        $GLOBALS['ui'][$this->self]['Shadow']->w = $this->w;
        
        $GLOBALS['ui'][$this->self]['innerShadow']->h = $this->h;
        $GLOBALS['ui'][$this->self]['Stroke']->h = $this->h;
        $GLOBALS['ui'][$this->self]['Caption']->h = $this->h;
        $GLOBALS['ui'][$this->self]['Shadow']->h = $this->h;  
        
        IF( is_numeric( $this->font_size ) And $this->font_size > 1 )
        {
            $GLOBALS['ui'][$this->self]['innerShadow']->font->size = $this->font_size;
            $GLOBALS['ui'][$this->self]['Stroke']->font->size = $this->font_size;
            $GLOBALS['ui'][$this->self]['Caption']->font->size = $this->font_size;
            $GLOBALS['ui'][$this->self]['Shadow']->font->size = $this->font_size;
            $this->font->size = $this->font_size;
        }  
        
        $GLOBALS['ui'][$this->self]['Caption']->cursor = $this->cursor;
        $GLOBALS['ui'][$this->self]['Caption']->hint = $this->hint;
        
        IF( $this->inner_shadow_color <> $this->def_color )
        $GLOBALS['ui'][$this->self]['innerShadow']->font->color = $this->inner_shadow_color;
        IF( $this->stroke_color <> $this->def_color )
        $GLOBALS['ui'][$this->self]['Stroke']->font->color = $this->stroke_color;
        IF( $this->label_color <> $this->def_color )
        $GLOBALS['ui'][$this->self]['Caption']->font->color = $this->label_color;
        IF( $this->shadow_color <> $this->def_color )
        $GLOBALS['ui'][$this->self]['Shadow']->font->color = $this->shadow_color;
        
        IF( $this->stroke == True )
        $GLOBALS['ui'][$this->self]['Stroke']->visible = True;
        Else
        $GLOBALS['ui'][$this->self]['Stroke']->visible = False;
        
        IF( $this->shadow == True )
        $GLOBALS['ui'][$this->self]['Shadow']->visible = True;
        Else
        $GLOBALS['ui'][$this->self]['Shadow']->visible = False;
        
        IF( $this->inner_shadow == True )
        $GLOBALS['ui'][$this->self]['innerShadow']->visible = True;
        Else
        $GLOBALS['ui'][$this->self]['innerShadow']->visible = False;
        
        #Events
        $GLOBALS['ui'][$this->self]['Caption']->onClick = self::GetEvent( $this, 'onClick' );
        $GLOBALS['ui'][$this->self]['Caption']->onMouseDown = 'TUIButton::evDown('.$this->self.'); ' . self::GetEvent( $this, 'onMouseDown' ) . ' TUIButton::Nothing';
        $GLOBALS['ui'][$this->self]['Caption']->onMouseUp = 'TUIButton::evUp('.$this->self.'); ' . self::GetEvent( $this, 'onMouseUp' ) . ' TUIButton::Nothing';
        $GLOBALS['ui'][$this->self]['Caption']->onMouseMove = self::GetEvent( $this, 'onMouseMove' ) . ' TUIButton::Nothing';
        $GLOBALS['ui'][$this->self]['Caption']->onMouseEnter = 'TUIButton::evHover('.$this->self.'); ' . self::GetEvent( $this, 'onMouseEnter' );
        $GLOBALS['ui'][$this->self]['Caption']->onMouseLeave = 'TUIButton::evLeave('.$this->self.'); ' . self::GetEvent( $this, 'onMouseLeave' );
        
    }
            
    Public Static Function MassDelete( $File )
    {
        ForEach( func_get_args() As $File ) if( file_exists($File) And is_file($File) ) @unlink($File);
    }
    
    Public Static Function GetEvent( $object, $event = 'onclick' )
    {
        Return $GLOBALS[__exEvents][ $object->self ][events][ strtolower( $event ) ];
    }
}
?>
