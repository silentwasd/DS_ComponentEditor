<?

//TFlatEdit by SkripovShow
//Class for DevelStudio AE

class TFlatEdit extends TEdit {

	public $class_name_ex = __CLASS__;
	
		public function set_onMouseDown($v){
	
			event_set($this->self, 'onMouseDown', 'TFlatEdit::onMouseDown');
    	}
    
    	public function set_onMouseUp($v){
	
			event_set($this->self, 'onMouseUp', 'TFlatEdit::onMouseUp');
			
    	}

	public function __initComponentInfo(){

		event_set($this->self, 'onMouseDown', 'TFlatEdit::onMouseDown');
		event_set($this->self, 'onMouseUp', 'TFlatEdit::onMouseUp');
	
	}
	
	public function __construct($owner = nil, $init = true, $self = nil){
		parent::__construct($owner, $init, $self);
		
		if ( $init ){
		
			$this->caption = "FlatEdit";
			$this->fontColor = clWhite;
			$this->fontSize = 11;
			$this->fontName = 'Segoe UI';
			$this->color = 10271770;
			$this->transparent = false;
			$this->alignment = taCenter;
			$this->layout = tlCenter;
			$this->borderStyle = bsNone;
		}
		}
}