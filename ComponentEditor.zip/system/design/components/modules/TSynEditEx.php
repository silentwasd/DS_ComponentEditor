<?
Class TSynEditEx extends TSynEdit {
    
    Public $class_name_ex = __CLASS__;
    
	 Public Function __inspectProperties()
	{
	
		return true;
	 }
    
	 Public Function __initComponentInfo()
	{
		parent::__initComponentInfo();
		gui_propset($this->gutter, 'showlinenumbers', true);
		gui_propset($this->self, 'Options', '[eoAutoIndent, eoDragDropEditing, eoDropFiles, eoEnhanceEndKey, eoGroupUndo, eoHalfPageScroll, eoScrollPastEof, eoShowScrollHint, eoSmartTabDelete, eoTabsToSpaces, eoTrimTrailingSpaces]');
	 }
    
	Public Function __construct($onwer=nil,$init=true,$self=nil)
	{
		parent::__construct($onwer, $init, $self);
		gui_propset($this->gutter, 'showlinenumbers', true);
		gui_propset($this->self, 'Options', '[eoAutoIndent, eoDragDropEditing, eoDropFiles, eoEnhanceEndKey, eoGroupUndo, eoHalfPageScroll, eoScrollPastEof, eoShowScrollHint, eoSmartTabDelete, eoTabsToSpaces, eoTrimTrailingSpaces]');
	 }
	 
	function set_Highlighter($hl_name){ 
		gui_readstr($this->self, 
		'object '.$this->name.': TSynEdit
		Highlighter = '. str_replace('->', '.', $hl_name->name) .' 
		end'); 
	}
}
?>
