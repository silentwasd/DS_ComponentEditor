<?

//TFlatMemo by SkripovShow
//Class for DevelStudio AE

class TFlatMemo extends TMemo {

	public $class_name_ex = __CLASS__;
	
		public function set_onMouseDown($v){
	
			event_set($this->self, 'onMouseDown', 'TFlatMemo::onMouseDown');
    	}
    
    	public function set_onMouseUp($v){
	
			event_set($this->self, 'onMouseUp', 'TFlatMemo::onMouseUp');
			
    	}

	public function __initComponentInfo(){

		event_set($this->self, 'onMouseDown', 'TFlatMemo::onMouseDown');
		event_set($this->self, 'onMouseUp', 'TFlatMemo::onMouseUp');
	
	}
	
	public function __construct($owner = nil, $init = true, $self = nil){
		parent::__construct($owner, $init, $self);
		
		if ( $init ){
		
			$this->caption = "FlatMemo";
			$this->fontColor = clWhite;
			$this->fontSize = 11;
			$this->fontName = 'Segoe UI';
			$this->color = 10271770;
			$this->transparent = false;
			$this->alignment = taLeftJustify;
			$this->layout = tlCenter;
			$this->borderStyle = bsNone;
		}
		}
}