<?

class ozButton extends TLabel {
	
	public $class_name_ex = __CLASS__;

	public function __initComponentInfo(){
		
		$shape = new TShape();
		$shape->parent = $this->parent;
		$shape->brushColor = 16514043;
		$shape->penColor = 15921906;
		$shape->x = $this->x;
		$shape->y = $this->y;
		$shape->w = $this->w;
		$shape->h = $this->h;
		$shape->name = $this->name . "Shape";
		
		$this->transparent = true;
		$this->toFront();
		
	}
	
	public function __construct($owner = nil, $init = true, $self = nil){
		parent::__construct($owner, $init, $self);
		
		if ($init){
			$this->font->name = "Segoe UI Light";
			$this->font->color = dechex("#111111");
			//$this->font->color = 16777215;
			$this->font->size = 12;
			$this->alignment = taCenter;
			$this->layout = tlCenter;
			$this->transparent = false;
			$this->color = 16514043;
			$this->autoSize = false;
			$this->w = 128;
			$this->h = 32;
		}
	}
	
}