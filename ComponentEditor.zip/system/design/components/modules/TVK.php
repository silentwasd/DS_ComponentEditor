<?
class TVK extends __TNoVisual
 { 	public $class_name_ex = __CLASS__;
	
 	public function __construct($onwer=nil,$init=true,$self=nil)
 	{
		parent::__construct($onwer, $init, $self);
        	if ($init)
        	{        		/*        		$this->onCheckSessionFunc = 'FunctionName';
	    		$this->onCheckSession = true;
	    		*/
			}
 	}

	public function __initComponentInfo()
	{
		parent::__initComponentInfo();
		/*
		if($this->onCheckSessionFunc)
		{        	$this->IsAuth($this->onCheckSessionFunc);
		}
		*/
    }
	
	public function Auth()
	{
		VK4DS_Base::Auth(2800712, 2079999);
	}
	
	public function GetAccessToken( )
	{
		return VK4DS_Base::GetAccessToken( );
	}
	
	public function GetUserId( )
	{
		return VK4DS_Base::GetUserId( );
	}
	
	public function GetExpiresIn( )
	{
		return VK4DS_Base::GetExpiresIn( );
	}
	
	public function SendAsync( $Method, $Parameters, $Callback )
	{
		VK4DS_Base::AsyncAPI( $Method, $Parameters, $Callback );
	}
	
	public function Send( $Method, $Parameters )
	{
		return VK4DS_Base::API($Method, $Parameters );
	}
	
	public function IsAuth( )
	{
		VK4DS_Base::IsAuth();
	}
	
	public Function GetPath($sid){
        return sys_get_temp_dir().'/'.strtoupper(md5($sid.'VK4DS')).'.session';
    }
    public Function Save($sid){
        $File = $this->GetPath($sid);
        file_put_contents( $File, json_encode( array('access_token'=>VK4DS_Base::GetAccessToken(), 'expires_in'=>VK4DS_Base::GetExpiresIn(), 'user_id'=>VK4DS_Base::GetUserId()) ) );
    }

    public Function Load($sid)
	{
        $File = $this->GetPath($sid);
        $config = json_decode(file_get_contents($File));
        vk4ds_config( $config->access_token, $config->expires_in, $config->user_id );
    }

    public Function Exists($sid)
    {
        return file_exists($this->GetPath($sid));
    }
	
	public function CheckSession($sid)
	{
		if( $this->Exists($sid) )
		{
			$this->Load($sid);
			return 1;
		} else {
			return 0;
		}
	}
 }

?>