<?

class ozSwitch extends TShape {
	
	public $class_name_ex = __CLASS__;
	
	public function __initComponentInfo(){
		
		$shape = new TShape($this->parent);
		$shape->parent = $this->parent;
		$shape->x = $this->x;
		$shape->y = $this->y;
		$shape->w = $this->w / 2;
		$shape->h = $this->h;
		$shape->brushColor = $this->disabledColor;
		$shape->penColor = 15329769;
		$shape->name = $this->name . "SW";
		
		$shape->create();
		
		event_set($this->self, 'onMouseUp', 'ozSwitch::onMouseUp');
		event_set($shape->self, 'onMouseUp', 'ozSwitch::onMouseUpSwitch');
		
		if ($this->smoothness){
			if (!class_exists("resize")){
				$this->smoothness = false;
				alert("��� �������� ������������ ���������� ���������� ����� Resizer.");
			}
		}
		
		if ($this->switched){
			$shape->x = $shape->x + $shape->w;
			$shape->brushColor = $this->enabledColor;
		}
		
	}
	
	public function __construct($owner = nil, $init = true, $self = nil){
		parent::__construct($owner, $init, $self);
		
		if ($init){
			$this->brushColor = 16777215;
			$this->penColor = 15329769;
			$this->enabledColor = 7457838;
			$this->disabledColor = 3951847;
		
		}
	}
	
	public static function onMouseUp($self){
		$switch = c($self);
		$switchShape = c($switch->name . "SW");
		
		if ($switch->smoothness){
			if (!class_exists("resize")){
				$switch->smoothness = false;
				alert("��� �������� ������������ ���������� ���������� ����� Resizer.");
				
				if ($switch->switched){
					$switchShape->x = $switch->x;
					$switchShape->brushColor = $switch->disabledColor;
					$switch->switched = false;
				} else {
					$switchShape->x = $switch->x + $switchShape->w;
					$switchShape->brushColor = $switch->enabledColor;
					$switch->switched = true;
				}
			} else {
				if ($switch->switched){
					resize::resize_object($switchShape, array("x" => $switch->x));
					$switchShape->brushColor = $switch->disabledColor;
					$switch->switched = false;
				} else {
					resize::resize_object($switchShape, array("x" => $switch->x + $switchShape->w));
					$switchShape->brushColor = $switch->enabledColor;
					$switch->switched = true;
				}
			}
		
		} else {
			if ($switch->switched){
				$switchShape->x = $switch->x;
				$switchShape->brushColor = $switch->disabledColor;
				$switch->switched = false;
			} else {
				$switchShape->x = $switch->x + $switchShape->w;
				$switchShape->brushColor = $switch->enabledColor;
				$switch->switched = true;
			}
			
		}
		
	}
	
	public static function onMouseUpSwitch($self){
		$name = str_replace("SW", null, c($self)->name);
		$switch = c($name);
		$switchShape = c($self);
		
		if ($switch->smoothness){
			if (!class_exists("resize")){
				$switch->smoothness = false;
				alert("��� �������� ������������ ���������� ���������� ����� Resizer.");
				
				if ($switch->switched){
					$switchShape->x = $switch->x;
					$switchShape->brushColor = $switch->disabledColor;
					$switch->switched = false;
				} else {
					$switchShape->x = $switch->x + $switchShape->w;
					$switchShape->brushColor = $switch->enabledColor;
					$switch->switched = true;
				}
			} else {
				if ($switch->switched){
					resize::resize_object($switchShape, array("x" => $switch->x));
					$switchShape->brushColor = $switch->disabledColor;
					$switch->switched = false;
				} else {
					resize::resize_object($switchShape, array("x" => $switch->x + $switchShape->w));
					$switchShape->brushColor = $switch->enabledColor;
					$switch->switched = true;
				}
			}
		
		} else {
			if ($switch->switched){
				$switchShape->x = $switch->x;
				$switchShape->brushColor = $switch->disabledColor;
				$switch->switched = false;
			} else {
				$switchShape->x = $switch->x + $switchShape->w;
				$switchShape->brushColor = $switch->enabledColor;
				$switch->switched = true;
			}
			
		}
		
	}
	
}