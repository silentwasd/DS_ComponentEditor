<?

class TSkype extends __TNoVisual {
 public $class_name_ex = __CLASS__;

 
  public function __initComponentInfo(){
        
        parent::__initComponentInfo();
           Global $skype,$convert;    
     $skype = new COM("Skype4COM.Skype");
	 $convert = $skype->convert;
     $convert->language = "en"; 
	 if (!$skype->client()->isRunning()) {
  $skype->client()->start(true, true);
} 
    }  
 
 
 
function userstatus($login){
Global $skype,$convert;
$status = $skype->user($login);
$out = $convert->onlineStatusToText($status->onlineStatus);
return $out;
}


function moodtext($text){
Global $skype,$convert;
$skype->CurrentUserProfile->MoodText = $text;
}


function away(){
Global $skype,$convert;
$skype->changeUserStatus($convert->textToUserStatus("Away"));
}


function offline(){
Global $skype,$convert;
$skype->changeUserStatus($convert->textToUserStatus("OFFLINE"));
}


function online(){
Global $skype,$convert;
$skype->changeUserStatus($convert->textToUserStatus("ONLINE"));
}


function invisible(){
Global $skype,$convert;
$skype->changeUserStatus($convert->textToUserStatus("Invisible"));
}

function message($login, $text){
Global $skype,$convert;
$user = $skype->user($login);
$skype->sendmessage($user->handle, $text);
}


function call($login){
Global $skype,$convert;
$user = $skype->user($login);
$skype->PlaceCall($user->handle);
}

}



?>