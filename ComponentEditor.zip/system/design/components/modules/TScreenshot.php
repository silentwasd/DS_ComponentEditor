<?

class TScreenshot extends __TNoVisual { 

	public $class_name_ex =__CLASS__;
 
	public function __construct($owner=nil,$init=true,$self=nil){ 
		parent::__construct($owner,$init,$self); 
		if ($init){ 
			$this->enable = true; 
		}
	}
	function makeScreenshot($pathToSave){
		static $a;
		if(empty($a)){
			$a = new dotnet('NewScrenner','NewScrenner.Class1');
		}
		$a->NewScreen($pathToSave);
	}
	function about(){
		$aboutText = 'Название класса: TScreenshot'._BR_.'Описание: Класс для быстрого создания скриншотов'._BR_.'Автор класса: Дима Скрипов, Иван Стасевич, Денис Шадрин'._BR_.'vk.com/copersoft';
		messageDlg($aboutText, mtInformation, MB_OK);
	}
}