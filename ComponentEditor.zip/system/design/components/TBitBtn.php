<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TButton_Caption');
$result['SORT']    = 110;
$result['NAME']    = 'button';

$result['W'] = 20;
$result['H'] = 4;

//$result['MODULES'] = array('php_squall.dll');

return $result;