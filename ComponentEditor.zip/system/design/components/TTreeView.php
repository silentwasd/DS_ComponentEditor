<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TTreeView_Caption');
$result['SORT']    = 495;
$result['NAME']    = 'tree';
$result['W']       = 20;
$result['H']       = 20;

return $result;