<?

$result = array();

$result['GROUP']   = 'dialogs';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TFontDialogEx_Caption');
$result['SORT']    = 1040;
$result['NAME']    = 'fontDlg';

//$result['MODULES'] = array('php_squall.dll');

return $result;