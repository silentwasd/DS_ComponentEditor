<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TStatusBar_Caption');
$result['SORT']    = 294;
$result['NAME']    = 'statusBar';
$result['WINCONTROL'] = true;

$result['W'] = 30;
$result['H'] = 3;

$result['IS_ONE'] = true;

return $result;