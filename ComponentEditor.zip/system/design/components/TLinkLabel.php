<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TLinkLabel_Caption');
$result['SORT']    = 201;
$result['NAME']    = 'link';

$result['PROPS'] = array('autoSize' => true);
$result['W'] = 10;
$result['H'] = 2;

return $result;