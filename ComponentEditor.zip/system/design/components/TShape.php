<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TShape_Caption');
$result['SORT']    = 237;

$result['NAME']    = 'shape';

$result['W'] = 20;
$result['H'] = 15;

return $result;