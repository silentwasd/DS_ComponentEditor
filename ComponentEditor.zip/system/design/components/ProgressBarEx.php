<?

//**************************************************//
//********************ProgressBarEx2.2**************//
//********************By Roman**********************//
//**************************************************//

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('ProgressBarEx');
$result['SORT']    = 410;

$result['NAME']    = 'ProgressEx';

$result['W'] = 54;
$result['H'] = 3;

return $result;