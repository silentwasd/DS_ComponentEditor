<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('Flat Button');
$result['SORT']    = 2000;
$result['NAME']    = 'flatButton';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 15;
$result['H'] = 2;

return $result;