<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('NextInspector');
$result['SORT']    = 110;
$result['NAME']    = 'nextInspector';

$result['W'] = 20;
$result['H'] = 44;

//$result['MODULES'] = array('php_squall.dll');

return $result;