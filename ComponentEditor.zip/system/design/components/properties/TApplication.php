<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Title'),
                  'TYPE'=>'number',
                  'PROP'=>'title',
                  );
return $result;