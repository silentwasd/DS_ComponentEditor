<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('Text'),
                  'TYPE'=>'text',
                  'PROP'=>'findText',
                  );
return $result;