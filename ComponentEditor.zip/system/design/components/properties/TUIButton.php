<?
$result = array();

$result[] = array(
                  'CAPTION'=>'Pack Path',
                  'TYPE'=>'text',
                  'PROP'=>'uipack',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Use Default Pack',
                  'TYPE'=>'check',
                  'PROP'=>'default_pack',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Skin Name',
                  'TYPE'=>'text',
                  'PROP'=>'uiname',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Dynamic Label',
                  'TYPE'=>'check',
                  'PROP'=>'dyn_label',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Stroke',
                  'TYPE'=>'check',
                  'PROP'=>'stroke',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Inner Shadow',
                  'TYPE'=>'check',
                  'PROP'=>'inner_shadow',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array(
                  'CAPTION'=>'Shadow',
                  'TYPE'=>'check',
                  'PROP'=>'shadow',
                  'UPDATE_DSGN'=>1
                  );

$result[] = array('CAPTION'=>'Label Color', 'TYPE'=>'color', 'PROP'=>'label_color');
$result[] = array('CAPTION'=>'Stroke Color', 'TYPE'=>'color', 'PROP'=>'stroke_color');
$result[] = array('CAPTION'=>'Inner Shadow Color', 'TYPE'=>'color', 'PROP'=>'inner_shadow_color');
$result[] = array('CAPTION'=>'Shadow Color', 'TYPE'=>'color', 'PROP'=>'shadow_color');
$result[] = array('CAPTION'=>'Font Size', 'PROP'=>'font_size','TYPE'=>'text', 'UPDATE_DSGN'=>1);

$result[] = array(
                  'CAPTION'=>t('caption'),
                  'TYPE'=>'text',
                  'PROP'=>'caption',
                  );

$result[] = array(
                  'CAPTION'=>t('Hint'),
                  'TYPE'=>'text',
                  'PROP'=>'hint',
                  );

$result[] = array(
                  'CAPTION'=>t('Cursor'),
                  'TYPE'=>'combo',
                  'PROP'=>'cursor',
                  'VALUES'=>$GLOBALS['cursors_meta'],
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t('Sizes and position'),
                  'TYPE'=>'sizes',
                  'PROP'=>'',
                  'ADD_GROUP'=>true,
                  'UPDATE_DSGN'=>1,
                  );

$result[] = array(
                  'CAPTION'=>t('Enabled'),
                  'TYPE'=>'check',
                  'PROP'=>'aenabled',
                  'REAL_PROP'=>'enabled',
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t('visible'),
                  'TYPE'=>'check',
                  'PROP'=>'avisible',
                  'REAL_PROP'=>'visible',
                  'ADD_GROUP'=>true,
                  );

$result[] = array('CAPTION'=>t('p_Left'), 'PROP'=>'x','TYPE'=>'number','ADD_GROUP'=>true,'UPDATE_DSGN'=>1);
$result[] = array('CAPTION'=>t('p_Top'), 'PROP'=>'y','TYPE'=>'number','ADD_GROUP'=>true,'UPDATE_DSGN'=>1);
$result[] = array('CAPTION'=>t('Width'), 'PROP'=>'w','TYPE'=>'number','ADD_GROUP'=>true,'UPDATE_DSGN'=>1);
$result[] = array('CAPTION'=>t('Height'), 'PROP'=>'h','TYPE'=>'number','ADD_GROUP'=>true,'UPDATE_DSGN'=>1);

return $result;

?>