<?

$result = array();

$result[] = array(
                  'CAPTION'=>'Alternative Link',
                  'TYPE'=>'text',
                  'PROP'=>'alternate',
                  );
				  
return $result;