<? $result =array(); $result[] =array( 'CAPTION'=>t('Align'), 'TYPE'=>'combo', 'PROP'=>'align', 'VALUES'=>array('alNone', 'alTop', 'alBottom', 'alLeft', 'alRight', 'alClient', 'alCustom'), 'ADD_GROUP'=>true );$result[] =array( 'CAPTION'=>t('Text'), 'TYPE'=>'text', 'PROP'=>'caption', 'UPDATE_DSGN'=>1 );$result[] =array( 'CAPTION'=>t('font'), 'TYPE'=>'font', 'PROP'=>'font', 'CLASS'=>'TFont', 'UPDATE_DSGN'=>1 );$result[] =array('CAPTION'=>t('Font color'), 'PROP'=>'font->color'); $result[] =array('CAPTION'=>t('Font size'), 'PROP'=>'font->size'); $result[] =array('CAPTION'=>t('Font style'), 'PROP'=>'font->style'); $result[] =array( 'CAPTION'=>t('Color'), 'TYPE'=>'color', 'PROP'=>'color' );$result[] =array('CAPTION'=>t('One Color_'), 'TYPE'=>'color', 'PROP'=>'OneColor'); $result[] =array('CAPTION'=>t('Two Color_'), 'TYPE'=>'color', 'PROP'=>'TwoColor'); $result[] =array('CAPTION'=>t('Three Color_'), 'TYPE'=>'color', 'PROP'=>'ThreeColor'); $result[] =array('CAPTION'=>t('Four Color_'), 'TYPE'=>'color', 'PROP'=>'FourColor'); $result[] =array( 'CAPTION'=>t('Auto Size'), 'TYPE'=>'check', 'PROP'=>'autoSize', 'UPDATE_DSGN'=>1 );$result[] =array( 'CAPTION'=>t('Word Wrap'), 'TYPE'=>'check', 'PROP'=>'wordWrap' );$result[] =array( 'CAPTION'=>t('Hint'), 'TYPE'=>'text', 'PROP'=>'hint' );$result[] =array( 'CAPTION'=>t('Cursor'), 'TYPE'=>'combo', 'PROP'=>'cursor', 'VALUES'=>$GLOBALS['cursors_meta'], 'ADD_GROUP'=>true );$result[] =array( 'CAPTION'=>t('Sizes and position'), 'TYPE'=>'sizes', 'PROP'=>'', 'ADD_GROUP'=>true );$result[] =array( 'CAPTION'=>t('Enabled'), 'TYPE'=>'check', 'PROP'=>'enabled', 'REAL_PROP'=>'enabled', 'ADD_GROUP'=>true );$result[] =array( 'CAPTION'=>t('visible'), 'TYPE'=>'check', 'PROP'=>'visible', 'REAL_PROP'=>'visible', 'ADD_GROUP'=>true );$result[] =array('CAPTION'=>t('p_Left'), 'PROP'=>'x','TYPE'=>'number','ADD_GROUP'=>1,'UPDATE_DSGN'=>1); $result[] =array('CAPTION'=>t('p_Top'), 'PROP'=>'y','TYPE'=>'number','ADD_GROUP'=>1,'UPDATE_DSGN'=>1); $result[] =array('CAPTION'=>t('Width'), 'PROP'=>'w','TYPE'=>'number','ADD_GROUP'=>1,'UPDATE_DSGN'=>1); $result[] =array('CAPTION'=>t('Height'), 'PROP'=>'h','TYPE'=>'number','ADD_GROUP'=>1,'UPDATE_DSGN'=>1); return $result;
/*
    
$$$$$___$$$$$___$$$$$$__$$$$$$__$$$$$___$$$$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$____$$__$$____$$______$$____$$$$____$$__$$
$$______$$__$$____$$______$$____$$______$$__$$
$$$$$___$$$$$___$$$$$$____$$____$$$$$___$$$$$

        $$$$$___$$__$$
        $$__$$___$$$$
        $$$$$_____$$
        $$__$$____$$
        $$$$$_____$$

_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$
$$______$$______$$$_$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$____$$_$$$__$$______$$$$$$____$$____$$______$$$$
____$$__$$______$$__$$__$$__$$__$$__$$____$$____$$__$$__$$_$$
_$$$$___$$$$$___$$__$$___$$$$___$$__$$__$$$$$$___$$$$___$$__$$

*/