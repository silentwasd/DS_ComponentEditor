<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('Text'),
                  'TYPE'=>'text',
                  'PROP'=>'findText',
                  );
				  $result[] = array(
                  'CAPTION'=>t('ReplaceText'),
                  'TYPE'=>'text',
                  'PROP'=>'replaceText',
                  );
return $result;