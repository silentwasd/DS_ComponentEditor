<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Color'),
                  'TYPE'=>'color',
                  'PROP'=>'myBrushColor',
                  'UPDATE_DSNG'=>1
                  );

$result[] = array(
                  'CAPTION'=>t('Pen Color'),
                  'TYPE'=>'color',
                  'PROP'=>'myPenColor',
                  'UPDATE_DSNG'=>1
                  );

$result[] = array(
                  'CAPTION'=>'���� ��� ���������',
                  'TYPE'=>'color',
                  'PROP'=>'leaveColor',
                  'UPDATE_DSNG'=>1
                  );

$result[] = array(
                  'CAPTION'=>'���� ��� �����',
                  'TYPE'=>'color',
                  'PROP'=>'myClickColor',
                  );

$result[] = array(
                  'CAPTION'=>t('Pen Width'),
                  'TYPE'=>'number',
                  'PROP'=>'myPenWidth',
                  'UPDATE_DSNG'=>1
                  );

$result[] = array(
                  'CAPTION'=>'������ ��������� ��� ���������',
                  'TYPE'=>'number',
                  'PROP'=>'myPenWidthLeave',
                  'UPDATE_DSNG'=>1
                  );

$result[] = array(
                  'CAPTION'=>t('Anchors'),
                  'TYPE'=>'combo',
                  'PROP'=>'anchors',
                  'VALUES'=>array('akNone', 'akTop', 'akBottom', 'akLeft', 'akRight'),
                  );

$result[] = array(
                  'CAPTION'=>t('Hint'),
                  'TYPE'=>'text',
                  'PROP'=>'hint',
                  );

$result[] = array(
                  'CAPTION'=>t('Align'),
                  'TYPE'=>'combo',
                  'PROP'=>'align',
                  'VALUES'=>array('alNone', 'alTop', 'alBottom', 'alLeft', 'alRight', 'alClient', 'alCustom'),
                  'ADD_GROUP'=>true
                  );

$result[] = array(
                  'CAPTION'=>t('Cursor'),
                  'TYPE'=>'combo',
                  'PROP'=>'cursor',
                  'VALUES'=>$GLOBALS['cursors_meta'],
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t('Sizes and position'),
                  'TYPE'=>'sizes',
                  'PROP'=>'',
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t('Enabled'),
                  'TYPE'=>'check',
                  'PROP'=>'aenabled',
                  'REAL_PROP'=>'enabled',
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t('visible'),
                  'TYPE'=>'check',
                  'PROP'=>'avisible',
                  'REAL_PROP'=>'visible',
                  'ADD_GROUP'=>true,
                  );

$result[] = array(
                  'CAPTION'=>t("Position").' X',
                  'TYPE'=>'number',
                  'PROP'=>'x',
                  'ADD_GROUP'=>true
                  );

$result[] = array(
                  'CAPTION'=>t("Position").' Y',
                  'TYPE'=>'number',
                  'PROP'=>'y',
                  'ADD_GROUP'=>true
                  );

$result[] = array(
                  'CAPTION'=>t("Width"),
                  'TYPE'=>'number',
                  'PROP'=>'w',
                  'ADD_GROUP'=>true
                  );

$result[] = array(
                  'CAPTION'=>t("Height"),
                  'TYPE'=>'number',
                  'PROP'=>'h',
                  'ADD_GROUP'=>true
                  );

return $result;

?>