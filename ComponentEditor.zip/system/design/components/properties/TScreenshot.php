<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Enable'),
                  'TYPE'=>'check',
                  'PROP'=>'enable',
                  );
return $result;