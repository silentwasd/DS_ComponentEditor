<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Defines'),
                  'TYPE'=>'',
                  'PROP'=>'defines',
                  );
return $result;