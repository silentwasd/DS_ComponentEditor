<?

$result = array();

$result[] = array(
                  'CAPTION'=>t('Enable'),
                  'TYPE'=>'check',
                  'PROP'=>'enabled',
                  );


return $result;