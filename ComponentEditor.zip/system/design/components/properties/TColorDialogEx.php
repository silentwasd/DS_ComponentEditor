<?

$result = array();


$result[] = array(
                  'CAPTION'=>t('Color'),
                  'TYPE'=>'color',
                  'PROP'=>'color',
                  );
$result[] = array(
                  'CAPTION'=>t('Small mode'),
                  'TYPE'=>'check',
                  'PROP'=>'smallMode',
                  );
return $result;