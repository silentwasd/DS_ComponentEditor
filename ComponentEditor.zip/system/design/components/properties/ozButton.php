<?
$result = array();

$result[] = array(
	'CAPTION' => 'Align',
	'TYPE' => 'combo',
	'PROP' => 'align',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array('alNone','alTop','alBottom','alLeft','alRight','alClient','alCustom'),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Text',
	'TYPE' => 'text',
	'PROP' => 'caption',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'font',
	'TYPE' => 'font',
	'PROP' => 'font',
	'REAL_PROP' => '',
	'CLASS' => 'TFont',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'Font color',
	'TYPE' => '',
	'PROP' => 'font->color',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Font size',
	'TYPE' => '',
	'PROP' => 'font->size',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Font style',
	'TYPE' => '',
	'PROP' => 'font->style',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Align',
	'TYPE' => 'combo',
	'PROP' => 'alignment',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array('taLeftJustify','taRightJustify','taCenter'),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Valign',
	'TYPE' => 'combo',
	'PROP' => 'layout',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array('tlTop','tlCenter','tlBottom'),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Word Wrap',
	'TYPE' => 'check',
	'PROP' => 'wordWrap',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Hint',
	'TYPE' => 'text',
	'PROP' => 'hint',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Cursor',
	'TYPE' => 'combo',
	'PROP' => 'cursor',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array('crDefault','crNone','crArrow','crCross','crIBeam','crSize','crSizeNESW','crSizeNS','crSizeNWSE','crSizeWE','crUpArrow','crHourGlass','crDrag','crNoDrop','crHSplit','crVSplit','crMultiDrag','crSQLWait','crNo','crAppStart','crHelp','crHandPoint'),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Sizes and position',
	'TYPE' => 'sizes',
	'PROP' => '',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'p_Left',
	'TYPE' => 'number',
	'PROP' => 'x',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'p_Top',
	'TYPE' => 'number',
	'PROP' => 'y',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'Width',
	'TYPE' => 'number',
	'PROP' => 'w',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'Height',
	'TYPE' => 'number',
	'PROP' => 'h',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

return $result;