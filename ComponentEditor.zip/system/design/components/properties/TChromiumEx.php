<?
$result = array();

$result[] = array(
	'CAPTION' => 'Align',
	'TYPE' => 'combo',
	'PROP' => 'align',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array('alNone','alTop','alBottom','alLeft','alRight','alClient','alCustom'),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Default Encoding',
	'TYPE' => 'text',
	'PROP' => 'defaultEncoding',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Default User CSS Path',
	'TYPE' => 'text',
	'PROP' => 'defaultCSSPath',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'URL',
	'TYPE' => '',
	'PROP' => 'url',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'HTML Code',
	'TYPE' => '',
	'PROP' => 'html',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Options',
	'TYPE' => '',
	'PROP' => 'options',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Drag Drop Disabled',
	'TYPE' => '',
	'PROP' => 'options->dragDropDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Load Drops Disabled',
	'TYPE' => '',
	'PROP' => 'options->loadDropsDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Encoding Detector Enabled',
	'TYPE' => '',
	'PROP' => 'options->encodingDetectorEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Javascript Disabled',
	'TYPE' => '',
	'PROP' => 'options->javascriptDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Javascript Open Windows Disallowed',
	'TYPE' => '',
	'PROP' => 'options->javascriptOpenWindowsDisallowed',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Javascript Close Windows Disallowed',
	'TYPE' => '',
	'PROP' => 'options->javascriptCloseWindowsDisallowed',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Javascript Access Clipboard Disallowed',
	'TYPE' => '',
	'PROP' => 'options->javascriptAccessClipboardDisallowed',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Dom Paste Disabled',
	'TYPE' => '',
	'PROP' => 'options->domPasteDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Caret Browsing Enabled',
	'TYPE' => '',
	'PROP' => 'options->caretBrowsingEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Java Disabled',
	'TYPE' => '',
	'PROP' => 'options->javaDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'PluginsDisabled',
	'TYPE' => '',
	'PROP' => 'options->pluginsDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Universal Access From File Urls Allowed',
	'TYPE' => '',
	'PROP' => 'options->universalAccessFromFileUrlsAllowed',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'File Access From File Urls Allowed',
	'TYPE' => '',
	'PROP' => 'options->fileAccessFromFileUrlsAllowed',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Web Security Disabled',
	'TYPE' => '',
	'PROP' => 'options->webSecurityDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Xss Auditor Enabled',
	'TYPE' => '',
	'PROP' => 'options->xssAuditorEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Image Load Disabled',
	'TYPE' => '',
	'PROP' => 'options->imageLoadDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Shrink Standalone Images To Fit',
	'TYPE' => '',
	'PROP' => 'options->shrinkStandaloneImagesToFit',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Site Specific Quirks Disabled',
	'TYPE' => '',
	'PROP' => 'options->siteSpecificQuirksDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Text Area Resize Disabled',
	'TYPE' => '',
	'PROP' => 'options->textAreaResizeDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Page Cache Disabled',
	'TYPE' => '',
	'PROP' => 'options->pageCacheDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Tab To Links Disabled',
	'TYPE' => '',
	'PROP' => 'options->tabToLinksDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Hyperlink Auditing Disabled',
	'TYPE' => '',
	'PROP' => 'options->hyperlinkAuditingDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'User Style Sheet Enabled',
	'TYPE' => '',
	'PROP' => 'options->userStyleSheetEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Author And User Styles Disabled',
	'TYPE' => '',
	'PROP' => 'options->authorAndUserStylesDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Local Storage Disabled',
	'TYPE' => '',
	'PROP' => 'options->localStorageDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Databases Disabled',
	'TYPE' => '',
	'PROP' => 'options->databasesDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Application Cache Disabled',
	'TYPE' => '',
	'PROP' => 'options->applicationCacheDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Webgl Disabled',
	'TYPE' => '',
	'PROP' => 'options->webglDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Accelerated Compositing Enabled',
	'TYPE' => '',
	'PROP' => 'options->acceleratedCompositingEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Threaded Compositing Enabled',
	'TYPE' => '',
	'PROP' => 'options->threadedCompositingEnabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Accelerated Layers Disabled',
	'TYPE' => '',
	'PROP' => 'options->acceleratedLayersDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Accelerated 2d Canvas Disabled',
	'TYPE' => '',
	'PROP' => 'options->accelerated2dCanvasDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Developer Tools Disabled',
	'TYPE' => '',
	'PROP' => 'options->developerToolsDisabled',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'Sizes and position',
	'TYPE' => 'sizes',
	'PROP' => '',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '',
);

$result[] = array(
	'CAPTION' => 'p_Left',
	'TYPE' => 'number',
	'PROP' => 'x',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'p_Top',
	'TYPE' => 'number',
	'PROP' => 'y',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'Width',
	'TYPE' => 'number',
	'PROP' => 'w',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

$result[] = array(
	'CAPTION' => 'Height',
	'TYPE' => 'number',
	'PROP' => 'h',
	'REAL_PROP' => '',
	'CLASS' => '',
	'VALUES' => array(),
	'ADD_GROUP' => '1',
	'UPDATE_DSGN' => '1',
);

return $result;