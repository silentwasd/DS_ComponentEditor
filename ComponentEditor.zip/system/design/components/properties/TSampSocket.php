<?

$result = array();

$result[] = array(
                  'CAPTION'=>'Host',
                  'TYPE'=>'text',
                  'PROP'=>'host',
                  );

$result[] = array(
                  'CAPTION'=>'Port',
                  'TYPE'=>'number',
                  'PROP'=>'port',
                  );



return $result;

?>