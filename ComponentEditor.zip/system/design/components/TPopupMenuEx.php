<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TPopupMenu_Caption');
$result['SORT']    = 730;
$result['NAME']    = 'popupMenu';


return $result;