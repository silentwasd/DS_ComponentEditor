<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = 'WinAPI';
$result['SORT']    = 1600;
$result['NAME']    = 'WinAPI';

return $result;