<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('THotKey_Caption');
$result['SORT']    = 470;
$result['NAME']    = 'hotKey';
$result['WINCONTROL'] = false;

$result['W'] = 25;
$result['H'] = 3;

return $result;