<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TSynEdit_Caption');
$result['SORT']    = 999;

$result['NAME']    = 'synEdit';

$result['W'] = 20;
$result['H'] = 15;

return $result;