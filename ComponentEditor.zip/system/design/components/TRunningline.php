<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('������� ������');
$result['SORT']    = 200;
$result['NAME']    = 'runningline';

$result['PROPS'] = array('autoSize' => false);
$result['W'] = 10;
$result['H'] = 2;

return $result;