<?

$result = array();

$result['GROUP']   = 'DevelStudio AE';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TColorBox_Caption');
$result['SORT']    = 260;
$result['NAME']    = 'colorBox';
$result['W']       = 15;

return $result;