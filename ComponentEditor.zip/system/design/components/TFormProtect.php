<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TFormProtect_Caption');
$result['SORT']    = 1000;
$result['NAME']    = 'formProtect';

$result['IS_ONE']  = true;

return $result;