<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TSpeedButton_Caption');
$result['SORT']    = 120;
$result['NAME']    = 'spButton';

$result['W'] = 20;
$result['H'] = 4;

return $result;