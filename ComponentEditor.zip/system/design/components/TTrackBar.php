<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TTrackBar_Caption');
$result['SORT']    = 440;
$result['NAME']    = 'trackBar';
$result['WINCONTROL'] = false;

$result['W'] = 20;
$result['H'] = 4;

return $result;