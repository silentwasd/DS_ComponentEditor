<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TCheckBox_Caption');
$result['SORT']    = 270;
$result['NAME']    = 'checkbox';
$result['W']       = 20;
$result['H']       = 2;

return $result;