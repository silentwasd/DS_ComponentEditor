<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TDateTimePicker_Caption');
$result['SORT']    = 490;
$result['NAME']    = 'dateTime';
$result['W']       = 20;
$result['H']       = 2;

return $result;