<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TScrollBox_Caption');
$result['SORT']    = 450;
$result['NAME']    = 'scrollBox';
$result['WINCONTROL'] = true;

$result['W'] = 20;
$result['H'] = 15;

return $result;