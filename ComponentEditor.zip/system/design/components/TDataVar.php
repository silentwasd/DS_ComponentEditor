<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TDataVar_Caption');
$result['SORT']    = 613;
$result['NAME']    = 'data';

return $result;