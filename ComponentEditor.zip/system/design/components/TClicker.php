<?
$result = array();

$result['CLASS'] = 'TClicker';
$result['GROUP'] = 'DevelStudio AE';
$result['CAPTION'] = '������';
$result['NAME'] = 'clicker';
$result['SORT'] = '1000';
$result['W'] = '';
$result['H'] = '';
$result['MODULES'] = array();
return $result;