<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TCombobox_Caption');
$result['SORT']    = 260;
$result['NAME']    = 'combobox';
$result['W']       = 15;

return $result;