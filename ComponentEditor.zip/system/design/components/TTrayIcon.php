<?

$result = array();

$result['GROUP']   = 'system';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TTrayIcon_Caption');
$result['SORT']    = 780;
$result['NAME']    = 'trayIcon';

$result['IS_ONE']  = true;

return $result;