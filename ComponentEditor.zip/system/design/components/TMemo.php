<?

$result = array();

$result['GROUP']   = 'main';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TMemo_Caption');
$result['SORT']    = 230;

$result['NAME']    = 'memo';

$result['W'] = 20;
$result['H'] = 15;

return $result;