<?

$result = array();

$result['GROUP']   = 'additional';
$result['CLASS']   = basenameNoExt(__FILE__);
$result['CAPTION'] = t('TGroupBox_Caption');
$result['SORT']    = 430;
$result['NAME']    = 'groupBox';
$result['WINCONTROL'] = true;

$result['W'] = 40;
$result['H'] = 25;

return $result;